#!/usr/bin/env bash
# Leave Desk first-time setup. Run once on the server from this folder:  ./setup.sh
set -euo pipefail
cd "$(dirname "$0")"

if ! command -v docker >/dev/null 2>&1 || ! docker compose version >/dev/null 2>&1; then
  echo "Docker with the compose plugin is not installed. See README.md, step 2."; exit 1
fi
if [ -f .env ]; then
  echo ".env already exists. To start again, delete .env first (this does not delete any data)."; exit 1
fi

echo "== Leave Desk setup =="
read -rp "Web address for the app (e.g. leave.yourcompany.ae): " DOMAIN
read -rp "Company name shown to staff: " COMPANY
read -rp "Your email (first HR administrator): " ADMIN_EMAIL
read -rp "Your name: " ADMIN_NAME
read -rp "Time zone [Asia/Dubai]: " TZONE
TZONE=${TZONE:-Asia/Dubai}

rand() { openssl rand -hex "$1"; }
DB_PASSWORD=$(rand 24)
SESSION_SECRET=$(rand 32)
ADMIN_PASSWORD="Ld-$(rand 6)"

if [[ "$DOMAIN" == :* ]]; then APP_URL="http://$(hostname -I | awk '{print $1}')"; else APP_URL="https://$DOMAIN"; fi

cat > .env <<ENV
DOMAIN=$DOMAIN
APP_URL=$APP_URL
DB_PASSWORD=$DB_PASSWORD
SESSION_SECRET=$SESSION_SECRET
ADMIN_EMAIL=$ADMIN_EMAIL
ADMIN_NAME=$ADMIN_NAME
ADMIN_PASSWORD=$ADMIN_PASSWORD
COMPANY_NAME=$COMPANY
APP_TIMEZONE=$TZONE
VAPID_PUBLIC_KEY=
VAPID_PRIVATE_KEY=
VAPID_SUBJECT=mailto:$ADMIN_EMAIL
SMTP_HOST=
SMTP_PORT=587
SMTP_USER=
SMTP_PASSWORD=
SMTP_FROM=
ENV
chmod 600 .env

echo "Building the app (this takes a few minutes the first time)…"
docker compose build app

echo "Creating push notification keys…"
KEYS=$(docker compose run --rm --no-deps -T --entrypoint node app -e \
  "const k=require('web-push').generateVAPIDKeys();console.log(k.publicKey+' '+k.privateKey)")
read -r PUB PRIV <<<"$KEYS"
sed -i "s|^VAPID_PUBLIC_KEY=.*|VAPID_PUBLIC_KEY=$PUB|; s|^VAPID_PRIVATE_KEY=.*|VAPID_PRIVATE_KEY=$PRIV|" .env

echo "Starting…"
docker compose up -d

echo
echo "================================================================"
echo " Leave Desk is starting at:   $APP_URL"
echo " HR dashboard:                $APP_URL/hr"
echo " HR sign-in email:            $ADMIN_EMAIL"
echo " HR sign-in password:         $ADMIN_PASSWORD"
echo
echo " Write the password down, sign in, and change it under My account."
echo " HTTPS can take a minute to switch on the first time."
echo "================================================================"
