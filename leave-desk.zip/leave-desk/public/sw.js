// Leave Desk service worker: shows push notifications for HR and opens the dashboard on tap.
self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", (e) => e.waitUntil(self.clients.claim()));

self.addEventListener("push", (event) => {
  let data = {};
  try { data = event.data ? event.data.json() : {}; } catch { data = { title: "Leave Desk", body: event.data && event.data.text() }; }
  event.waitUntil(
    self.registration.showNotification(data.title || "Leave Desk", {
      body: data.body || "New leave request",
      icon: "/icon-192.png",
      badge: "/icon-192.png",
      tag: data.tag || "leave-desk",
      data: { url: data.url || "/hr" },
    }),
  );
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const url = (event.notification.data && event.notification.data.url) || "/hr";
  event.waitUntil((async () => {
    const all = await self.clients.matchAll({ type: "window", includeUncontrolled: true });
    for (const c of all) {
      if (new URL(c.url).pathname.startsWith("/hr")) { await c.focus(); return; }
    }
    await self.clients.openWindow(url);
  })());
});

// Pass every request straight to the network; the app needs live data.
self.addEventListener("fetch", () => {});
