import type { Config } from "tailwindcss";

export default {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#16222e",
        muted: "#5b6b7a",
        line: "#d6dde4",
        canvas: "#f3f5f7",
        sunk: "#e9edf1",
        brand: { DEFAULT: "#0d6b62", dark: "#0a564f", soft: "#d8eeea" },
        pending: { DEFAULT: "#a35c00", soft: "#fdf0dc" },
        ok: { DEFAULT: "#1d7a3e", soft: "#dff3e5" },
        bad: { DEFAULT: "#b4282f", soft: "#fbe3e4" },
      },
      fontFamily: {
        sans: [
          "system-ui", "-apple-system", "Segoe UI", "Roboto", "Noto Sans", "Noto Sans Arabic",
          "Noto Nastaliq Urdu", "Noto Sans Devanagari", "Noto Sans Malayalam", "sans-serif",
        ],
        mono: ["ui-monospace", "SFMono-Regular", "Menlo", "Consolas", "monospace"],
      },
    },
  },
  plugins: [],
} satisfies Config;
