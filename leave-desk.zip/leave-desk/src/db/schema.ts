/**
 * Leave Desk database schema.
 *
 * To change it: edit this file, then run `npm run db:generate` on your development
 * machine. That writes a new SQL migration into /drizzle. The server applies new
 * migrations automatically every time it starts.
 *
 * Future modules (attendance, documents, payroll) should link to `employees.id`.
 */
import { relations } from "drizzle-orm";
import {
  boolean, date, index, integer, jsonb, pgEnum, pgTable, text, timestamp, uniqueIndex,
} from "drizzle-orm/pg-core";

const id = () => text("id").primaryKey().$defaultFn(() => crypto.randomUUID());
const createdAt = () => timestamp("created_at", { withTimezone: true }).notNull().defaultNow();

export const staffType = pgEnum("staff_type", ["OFFICE", "SITE"]);
export const userRole = pgEnum("user_role", ["HR", "ADMIN"]);
export const leaveStatus = pgEnum("leave_status", ["PENDING", "APPROVED", "REJECTED", "CANCELLED"]);
/** CALENDAR: every day counts. WORKING: weekends and public holidays are skipped. */
export const countMode = pgEnum("count_mode", ["CALENDAR", "WORKING"]);

/** Everyone who can apply for leave. */
export const employees = pgTable("employees", {
  id: id(),
  empNo: text("emp_no").notNull().unique(), // the Employee ID people know, stored in capitals
  name: text("name").notNull(),
  mobile: text("mobile"),
  department: text("department"),
  site: text("site"),
  staffType: staffType("staff_type").notNull().default("OFFICE"),
  joiningDate: date("joining_date"),
  active: boolean("active").notNull().default(true),
  pinHash: text("pin_hash").notNull(),
  tokenVersion: integer("token_version").notNull().default(0), // bump to sign out everywhere
  failedLogins: integer("failed_logins").notNull().default(0),
  lockedUntil: timestamp("locked_until", { withTimezone: true }),
  lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
  createdAt: createdAt(),
});

/** HR team members and administrators. */
export const users = pgTable("users", {
  id: id(),
  email: text("email").notNull().unique(),
  name: text("name").notNull(),
  passwordHash: text("password_hash").notNull(),
  role: userRole("role").notNull().default("HR"),
  active: boolean("active").notNull().default(true),
  emailAlerts: boolean("email_alerts").notNull().default(true),
  tokenVersion: integer("token_version").notNull().default(0),
  failedLogins: integer("failed_logins").notNull().default(0),
  lockedUntil: timestamp("locked_until", { withTimezone: true }),
  lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
  createdAt: createdAt(),
});

export const leaveTypes = pgTable("leave_types", {
  id: id(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(), // English
  names: jsonb("names").$type<Record<string, string>>(), // translations: {"ar": "...", ...}
  daysPerYear: integer("days_per_year"), // null = no yearly limit
  countMode: countMode("count_mode").notNull().default("CALENDAR"),
  requiresAttachment: boolean("requires_attachment").notNull().default(false),
  active: boolean("active").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const leaveRequests = pgTable("leave_requests", {
  id: id(),
  refNo: text("ref_no").notNull().unique(),
  employeeId: text("employee_id").notNull().references(() => employees.id),
  leaveTypeId: text("leave_type_id").notNull().references(() => leaveTypes.id),
  startDate: date("start_date").notNull(), // 'YYYY-MM-DD'
  endDate: date("end_date").notNull(),
  days: integer("days").notNull(),
  reason: text("reason"),
  coverBy: text("cover_by"),
  contact: text("contact"),
  status: leaveStatus("status").notNull().default("PENDING"),
  hrNote: text("hr_note"),
  decidedById: text("decided_by_id").references(() => users.id),
  decidedAt: timestamp("decided_at", { withTimezone: true }),
  createdAt: createdAt(),
}, (t) => [
  index("leave_requests_status_idx").on(t.status),
  index("leave_requests_employee_idx").on(t.employeeId),
  index("leave_requests_dates_idx").on(t.startDate, t.endDate),
]);

export const attachments = pgTable("attachments", {
  id: id(),
  requestId: text("request_id").notNull().references(() => leaveRequests.id, { onDelete: "cascade" }),
  storedName: text("stored_name").notNull().unique(),
  originalName: text("original_name").notNull(),
  mimeType: text("mime_type").notNull(),
  size: integer("size").notNull(),
  createdAt: createdAt(),
});

export const holidays = pgTable("holidays", {
  id: id(),
  date: date("date").notNull(),
  name: text("name").notNull(),
}, (t) => [uniqueIndex("holidays_date_idx").on(t.date)]);

export const settings = pgTable("settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull(),
});

export const pushSubscriptions = pgTable("push_subscriptions", {
  id: id(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  endpoint: text("endpoint").notNull().unique(),
  p256dh: text("p256dh").notNull(),
  auth: text("auth").notNull(),
  createdAt: createdAt(),
});

/** Who did what and when. Only ever added to. */
export const auditLog = pgTable("audit_log", {
  id: id(),
  at: createdAt(),
  actorType: text("actor_type").notNull(), // HR, STAFF or SYSTEM
  actorId: text("actor_id"),
  action: text("action").notNull(),
  entity: text("entity").notNull(),
  entityId: text("entity_id"),
  details: jsonb("details"),
}, (t) => [index("audit_log_at_idx").on(t.at), index("audit_log_entity_idx").on(t.entity, t.entityId)]);

/* ---------- relations (used by db.query.*) ---------- */
export const employeesRelations = relations(employees, ({ many }) => ({ requests: many(leaveRequests) }));
export const usersRelations = relations(users, ({ many }) => ({ pushSubs: many(pushSubscriptions) }));
export const leaveTypesRelations = relations(leaveTypes, ({ many }) => ({ requests: many(leaveRequests) }));
export const leaveRequestsRelations = relations(leaveRequests, ({ one, many }) => ({
  employee: one(employees, { fields: [leaveRequests.employeeId], references: [employees.id] }),
  leaveType: one(leaveTypes, { fields: [leaveRequests.leaveTypeId], references: [leaveTypes.id] }),
  decidedBy: one(users, { fields: [leaveRequests.decidedById], references: [users.id] }),
  attachments: many(attachments),
}));
export const attachmentsRelations = relations(attachments, ({ one }) => ({
  request: one(leaveRequests, { fields: [attachments.requestId], references: [leaveRequests.id] }),
}));
export const pushSubscriptionsRelations = relations(pushSubscriptions, ({ one }) => ({
  user: one(users, { fields: [pushSubscriptions.userId], references: [users.id] }),
}));

export type Employee = typeof employees.$inferSelect;
export type User = typeof users.$inferSelect;
export type LeaveType = typeof leaveTypes.$inferSelect;
export type LeaveRequest = typeof leaveRequests.$inferSelect;
