import { NextResponse, type NextRequest } from "next/server";

// A quick first check so signed-out visitors go straight to the right sign-in page.
// Every page and action also checks the session properly on the server.
export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  if (pathname.startsWith("/me") && !req.cookies.has("ld_staff")) {
    return NextResponse.redirect(new URL("/login", req.url));
  }
  if (pathname.startsWith("/hr") && pathname !== "/hr/login" && !req.cookies.has("ld_hr")) {
    return NextResponse.redirect(new URL("/hr/login", req.url));
  }
  return NextResponse.next();
}

export const config = { matcher: ["/me/:path*", "/hr/:path*"] };
