import { pushEnabled } from "@/lib/notify";
import { Dashboard } from "./Dashboard";

export const dynamic = "force-dynamic";
export const metadata = { title: "Requests" };

export default function HrHome() {
  return <Dashboard pushKeyAvailable={pushEnabled()} />;
}
