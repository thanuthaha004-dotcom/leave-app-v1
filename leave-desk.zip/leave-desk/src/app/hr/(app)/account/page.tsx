import { requireHR } from "@/lib/auth";
import { emailEnabled } from "@/lib/notify";
import { AccountForms } from "./AccountForms";

export const dynamic = "force-dynamic";
export const metadata = { title: "My account" };

export default async function AccountPage() {
  const u = await requireHR();
  return (
    <>
      <div>
        <h1 className="text-2xl font-extrabold">My account</h1>
        <p className="text-sm text-muted">{u.name} · {u.email} · {u.role === "ADMIN" ? "Administrator" : "HR"}</p>
      </div>
      <AccountForms emailAlerts={u.emailAlerts} emailReady={emailEnabled()} />
    </>
  );
}
