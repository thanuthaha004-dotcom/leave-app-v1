"use client";

import { noReset } from "@/components/noReset";
import { useActionState, useTransition } from "react";
import { changePassword, setEmailAlerts } from "../../actions";

export function AccountForms({ emailAlerts, emailReady }: { emailAlerts: boolean; emailReady: boolean }) {
  const [state, action, pending] = useActionState(changePassword, undefined);
  const [busy, start] = useTransition();
  return (
    <div className="grid max-w-xl gap-4">
      <form key={state?.ok ? "done" : "form"} onSubmit={noReset(action)} className="card grid gap-3 p-5">
        <h2 className="text-lg font-extrabold">Change password</h2>
        <div><label className="field-label" htmlFor="current">Current password</label><input id="current" name="current" type="password" required autoComplete="current-password" className="input" /></div>
        <div><label className="field-label" htmlFor="next">New password (at least 10 characters)</label><input id="next" name="next" type="password" required minLength={10} autoComplete="new-password" className="input" /></div>
        <div><label className="field-label" htmlFor="again">New password again</label><input id="again" name="again" type="password" required autoComplete="new-password" className="input" /></div>
        {state?.error && <p className="alert-err">{state.error}</p>}
        {state?.ok && <p className="alert-ok">Password changed. Other devices have been signed out.</p>}
        <button className="btn-primary justify-self-start" disabled={pending}>Change password</button>
      </form>
      <section className="card grid gap-2 p-5">
        <h2 className="text-lg font-extrabold">Email alerts</h2>
        <label className="flex items-center gap-2 font-semibold">
          <input type="checkbox" defaultChecked={emailAlerts} disabled={busy} onChange={(e) => { const on = e.target.checked; start(() => setEmailAlerts(on)); }} className="h-4 w-4 accent-brand" />
          Email me when a new leave request arrives
        </label>
        {!emailReady && <p className="text-sm text-muted">Email isn't set up on the server yet, so no emails are sent.</p>}
      </section>
    </div>
  );
}
