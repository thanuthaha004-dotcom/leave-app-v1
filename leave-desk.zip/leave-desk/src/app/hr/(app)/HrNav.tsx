"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

export function HrNav({ links }: { links: { href: string; label: string }[] }) {
  const path = usePathname();
  return (
    <nav className="-mx-1 flex gap-1 overflow-x-auto">
      {links.map((l) => {
        const active = l.href === "/hr" ? path === "/hr" : path.startsWith(l.href);
        return (
          <Link key={l.href} href={l.href} aria-current={active ? "page" : undefined}
            className={`whitespace-nowrap rounded-full px-3 py-1.5 text-sm font-semibold ${active ? "bg-ink text-white" : "text-muted hover:bg-sunk hover:text-ink"}`}>
            {l.label}
          </Link>
        );
      })}
    </nav>
  );
}
