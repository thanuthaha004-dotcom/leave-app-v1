import { asc, gte } from "drizzle-orm";
import { db, holidays, leaveTypes, users } from "@/db";
import { requireAdmin } from "@/lib/auth";
import { getSettings } from "@/lib/settings";
import { parseWeekend } from "@/lib/leave";
import { emailEnabled, pushEnabled } from "@/lib/notify";
import { fmtDate, todayIso } from "@/lib/dates";
import { addHoliday, addLeaveType, deleteHoliday, saveGeneral, saveLeaveType } from "../../actions";
import { UsersSection } from "./UsersSection";

export const dynamic = "force-dynamic";
export const metadata = { title: "Settings" };

const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

export default async function SettingsPage() {
  const me = await requireAdmin();
  const [s, types, hols, hrUsers] = await Promise.all([
    getSettings(),
    db.select().from(leaveTypes).orderBy(asc(leaveTypes.sortOrder), asc(leaveTypes.name)),
    db.select().from(holidays).where(gte(holidays.date, `${Number(todayIso().slice(0, 4)) - 1}-01-01`)).orderBy(asc(holidays.date)),
    db.select({ id: users.id, name: users.name, email: users.email, role: users.role, active: users.active, lastLoginAt: users.lastLoginAt })
      .from(users).orderBy(asc(users.name)),
  ]);

  return (
    <>
      <h1 className="text-2xl font-extrabold">Settings</h1>

      <section className="card grid gap-4 p-5">
        <h2 className="text-lg font-extrabold">Company and weekends</h2>
        <form action={saveGeneral} className="grid gap-4">
          <div className="max-w-md">
            <label htmlFor="company_name" className="field-label">Company name (shown to staff)</label>
            <input id="company_name" name="company_name" defaultValue={s.company_name} className="input" />
          </div>
          {(["OFFICE", "SITE"] as const).map((t) => {
            const wk = parseWeekend(s[`weekend_${t}`]);
            return (
              <fieldset key={t}>
                <legend className="field-label">Weekly days off for {t === "OFFICE" ? "office" : "site"} staff</legend>
                <div className="flex flex-wrap gap-2">
                  {DAYS.map((d, i) => (
                    <label key={d} className="flex items-center gap-1.5 rounded-lg border border-line px-3 py-1.5 text-sm font-semibold">
                      <input type="checkbox" name={`weekend_${t}`} value={i} defaultChecked={wk.includes(i)} className="accent-brand" />{d}
                    </label>
                  ))}
                </div>
              </fieldset>
            );
          })}
          <p className="text-sm text-muted">Weekends and public holidays are skipped only for leave types counted in working days.</p>
          <button className="btn-primary justify-self-start">Save</button>
        </form>
      </section>

      <section className="card grid gap-4 p-5">
        <div>
          <h2 className="text-lg font-extrabold">Leave types</h2>
          <p className="text-sm text-muted">The starting values are common defaults. Check them against your contracts and UAE labour law. Leave an allowance empty for no yearly limit.</p>
        </div>
        <div className="grid gap-3">
          {types.map((t) => (
            <form key={t.id} action={saveLeaveType.bind(null, t.id)} className={`grid gap-3 rounded-lg border border-line p-3.5 ${t.active ? "" : "bg-sunk/60"}`}>
              <div className="grid gap-3 sm:grid-cols-[2fr_1fr_1.3fr_auto_auto_auto] sm:items-end">
                <div>
                  <label className="field-label" htmlFor={`n-${t.id}`}>Name</label>
                  <input id={`n-${t.id}`} name="name" defaultValue={t.name} className="input py-2" />
                </div>
                <div>
                  <label className="field-label" htmlFor={`d-${t.id}`}>Days per year</label>
                  <input id={`d-${t.id}`} name="daysPerYear" inputMode="numeric" defaultValue={t.daysPerYear ?? ""} className="input py-2" placeholder="No limit" />
                </div>
                <div>
                  <label className="field-label" htmlFor={`c-${t.id}`}>Count</label>
                  <select id={`c-${t.id}`} name="countMode" defaultValue={t.countMode} className="input py-2">
                    <option value="CALENDAR">Calendar days</option>
                    <option value="WORKING">Working days</option>
                  </select>
                </div>
                <label className="flex items-center gap-1.5 pb-2 text-sm font-semibold">
                  <input type="checkbox" name="requiresAttachment" defaultChecked={t.requiresAttachment} className="accent-brand" />Needs document
                </label>
                <label className="flex items-center gap-1.5 pb-2 text-sm font-semibold">
                  <input type="checkbox" name="active" defaultChecked={t.active} className="accent-brand" />In use
                </label>
                <button className="btn-ghost btn-sm mb-1">Save</button>
              </div>
              <details>
                <summary className="cursor-pointer text-sm font-semibold text-muted">Translations and order</summary>
                <div className="mt-3 grid gap-3 sm:grid-cols-5">
                  {[["ar", "Arabic"], ["hi", "Hindi"], ["ur", "Urdu"], ["ml", "Malayalam"]].map(([l, label]) => (
                    <div key={l}>
                      <label className="field-label" htmlFor={`${l}-${t.id}`}>{label}</label>
                      <input id={`${l}-${t.id}`} name={`name_${l}`} defaultValue={t.names?.[l] ?? ""} dir="auto" className="input py-2" />
                    </div>
                  ))}
                  <div>
                    <label className="field-label" htmlFor={`o-${t.id}`}>Order</label>
                    <input id={`o-${t.id}`} name="sortOrder" inputMode="numeric" defaultValue={t.sortOrder} className="input py-2" />
                  </div>
                </div>
              </details>
            </form>
          ))}
        </div>
        <form action={addLeaveType} className="flex flex-wrap items-end gap-2">
          <div>
            <label className="field-label" htmlFor="newType">Add a leave type</label>
            <input id="newType" name="name" required placeholder="e.g. Marriage leave" className="input py-2" />
          </div>
          <button className="btn-ghost">Add</button>
        </form>
      </section>

      <section className="card grid gap-4 p-5">
        <div>
          <h2 className="text-lg font-extrabold">Public holidays</h2>
          <p className="text-sm text-muted">Islamic holidays move each year, so add them once the dates are announced.</p>
        </div>
        <form action={addHoliday} className="flex flex-wrap items-end gap-2">
          <div><label className="field-label" htmlFor="hdate">Date</label><input id="hdate" name="date" type="date" required className="input py-2" /></div>
          <div><label className="field-label" htmlFor="hname">Name</label><input id="hname" name="name" required placeholder="e.g. Eid Al Fitr" className="input py-2" /></div>
          <button className="btn-ghost">Add holiday</button>
        </form>
        {hols.length > 0 ? (
          <ul className="grid gap-1.5 sm:grid-cols-2">
            {hols.map((h) => (
              <li key={h.id} className="flex items-center justify-between gap-2 rounded-lg bg-sunk px-3 py-2 text-sm">
                <span><b className="tnum">{fmtDate(h.date)}</b> · {h.name}</span>
                <form action={deleteHoliday.bind(null, h.id)}><button className="text-xs font-semibold text-bad hover:underline">Remove</button></form>
              </li>
            ))}
          </ul>
        ) : <p className="text-sm text-muted">No holidays added yet.</p>}
      </section>

      <UsersSection me={me.id} users={hrUsers.map((u) => ({ ...u, lastLoginAt: u.lastLoginAt?.toISOString() ?? null }))} />

      <section className="card grid gap-2 p-5">
        <h2 className="text-lg font-extrabold">Notifications</h2>
        <p className="text-sm"><Dot on={pushEnabled()} /> Phone and desktop push notifications {pushEnabled() ? "are set up." : "are off. Add the VAPID keys to the server's .env file (see the setup guide)."}</p>
        <p className="text-sm"><Dot on={emailEnabled()} /> Email alerts {emailEnabled() ? "are set up." : "are off. Add the SMTP settings to the server's .env file to turn them on."}</p>
      </section>
    </>
  );
}

function Dot({ on }: { on: boolean }) {
  return <span className={`me-1.5 inline-block h-2.5 w-2.5 rounded-full ${on ? "bg-ok" : "bg-line"}`} aria-hidden />;
}
