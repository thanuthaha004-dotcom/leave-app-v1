"use client";

import { noReset } from "@/components/noReset";
import { useActionState, useState, useTransition } from "react";
import { createUser, resetUserPassword, setUserActive, type UserState } from "../../actions";
import { fmtDateTime } from "@/lib/dates";

type U = { id: string; name: string; email: string; role: "HR" | "ADMIN"; active: boolean; lastLoginAt: string | null };

function TempPassword({ email, password }: { email: string; password: string }) {
  return (
    <div className="grid gap-1 rounded-lg border-2 border-dashed border-brand bg-brand-soft p-4 text-sm">
      <span>Temporary password for <b>{email}</b>. It is shown only once; ask them to change it under My account.</span>
      <span className="select-all font-mono text-lg font-bold text-brand">{password}</span>
    </div>
  );
}

export function UsersSection({ me, users }: { me: string; users: U[] }) {
  const [state, action, pending] = useActionState<UserState, FormData>(createUser, undefined);
  const [reset, setReset] = useState<{ email?: string; password?: string; error?: string } | null>(null);
  const [busy, start] = useTransition();
  return (
    <section className="card grid gap-4 p-5">
      <div>
        <h2 className="text-lg font-extrabold">HR team</h2>
        <p className="text-sm text-muted">HR users review requests and manage employees. Administrators can also change these settings.</p>
      </div>
      {state?.password && <TempPassword email={state.email!} password={state.password} />}
      {reset?.password && <TempPassword email={reset.email!} password={reset.password} />}
      <div className="overflow-x-auto">
        <table className="w-full min-w-[560px] text-left text-sm">
          <thead className="text-[11px] uppercase tracking-wider text-muted">
            <tr><th className="py-1.5">Name</th><th className="py-1.5">Email</th><th className="py-1.5">Role</th><th className="py-1.5">Last sign-in</th><th /></tr>
          </thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id} className={`border-t border-line ${u.active ? "" : "text-muted"}`}>
                <td className="py-2 font-semibold">{u.name}{!u.active && " (inactive)"}</td>
                <td className="py-2">{u.email}</td>
                <td className="py-2">{u.role === "ADMIN" ? "Administrator" : "HR"}</td>
                <td className="py-2 text-muted">{u.lastLoginAt ? fmtDateTime(u.lastLoginAt) : "Never"}</td>
                <td className="py-2 text-right">
                  {u.id !== me && (
                    <span className="inline-flex gap-1.5">
                      <button disabled={busy} className="btn-ghost btn-sm" onClick={() => start(async () => setReset(await resetUserPassword(u.id)))}>Reset password</button>
                      <button disabled={busy} className="btn-ghost btn-sm" onClick={() => start(() => setUserActive(u.id, !u.active))}>{u.active ? "Deactivate" : "Activate"}</button>
                    </span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <form key={state?.password ?? ""} onSubmit={noReset(action)} className="flex flex-wrap items-end gap-2">
        <div><label className="field-label" htmlFor="uname">Name</label><input id="uname" name="name" required className="input py-2" /></div>
        <div><label className="field-label" htmlFor="uemail">Email</label><input id="uemail" name="email" type="email" required className="input py-2" /></div>
        <div>
          <label className="field-label" htmlFor="urole">Role</label>
          <select id="urole" name="role" className="input py-2"><option value="HR">HR</option><option value="ADMIN">Administrator</option></select>
        </div>
        <button className="btn-ghost" disabled={pending}>Add HR user</button>
      </form>
      {state?.error && <p className="alert-err">{state.error}</p>}
    </section>
  );
}
