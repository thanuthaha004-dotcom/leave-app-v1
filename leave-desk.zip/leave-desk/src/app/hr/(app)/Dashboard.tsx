"use client";

import { useCallback, useEffect, useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { cancelApproved, decideRequest } from "../actions";
import { StatusPill } from "@/components/StatusPill";
import { fmtDate, fmtDateTime } from "@/lib/dates";

type Item = {
  id: string; refNo: string; status: string; startDate: string; endDate: string; days: number;
  reason: string | null; coverBy: string | null; contact: string | null; hrNote: string | null;
  createdAt: string; decidedAt: string | null; decidedBy: string | null;
  empNo: string; name: string; mobile: string | null; department: string | null; site: string | null; staffType: string;
  typeName: string; requiresAttachment: boolean; daysPerYear: number | null; usedThisYear: number | null;
  attachments: { id: string; name: string; type: string }[];
  employeeId: string;
};
type Data = {
  today: string;
  stats: { pending: number; today: number; siteToday: number; approvedMonth: number };
  pending: { id: string; name: string }[];
  items: Item[];
};

const VIEWS = [
  { id: "pending", label: "Waiting" },
  { id: "today", label: "On leave today" },
  { id: "upcoming", label: "Next 30 days" },
  { id: "decided", label: "Recent decisions" },
] as const;

const POLL_MS = 15_000;
const SEEN_KEY = "ld_seen";

function loadSeen(): Set<string> {
  try { return new Set(JSON.parse(localStorage.getItem(SEEN_KEY) || "[]")); } catch { return new Set(); }
}
function saveSeen(s: Set<string>) {
  try { localStorage.setItem(SEEN_KEY, JSON.stringify([...s].slice(-1000))); } catch { /* private mode */ }
}

export function Dashboard({ pushKeyAvailable }: { pushKeyAvailable: boolean }) {
  const router = useRouter();
  const [view, setView] = useState<string>("pending");
  const [q, setQ] = useState("");
  const [data, setData] = useState<Data | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [updatedAt, setUpdatedAt] = useState<Date | null>(null);
  const [sound, setSound] = useState(false);
  const [seen, setSeen] = useState<Set<string>>(() => new Set());
  const known = useRef<Set<string> | null>(null);
  const audio = useRef<AudioContext | null>(null);
  const pushOn = useRef(false);

  const showToast = useCallback((m: string) => {
    setToast(m);
    window.setTimeout(() => setToast((cur) => (cur === m ? null : cur)), 6000);
  }, []);

  const chime = useCallback(() => {
    const ctx = audio.current;
    if (!ctx) return;
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.connect(g); g.connect(ctx.destination);
    o.frequency.value = 880;
    g.gain.setValueAtTime(0.0001, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.25, ctx.currentTime + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.6);
    o.start(); o.stop(ctx.currentTime + 0.6);
  }, []);

  const load = useCallback(async () => {
    try {
      const res = await fetch(`/api/hr/requests?view=${view}&q=${encodeURIComponent(q)}`, { cache: "no-store" });
      if (res.status === 401) { router.push("/hr/login"); return; }
      if (!res.ok) throw new Error();
      const d: Data = await res.json();
      // Alert on requests that arrived since the last check.
      if (known.current) {
        const fresh = d.pending.filter((p) => !known.current!.has(p.id));
        if (fresh.length) {
          const msg = fresh.length === 1 ? `New leave request from ${fresh[0].name}` : `${fresh.length} new leave requests`;
          showToast(msg);
          if (sound) chime();
          if (document.hidden && !pushOn.current && "Notification" in window && Notification.permission === "granted") {
            new Notification("Leave Desk", { body: msg, tag: "leave-desk", icon: "/icon-192.png" });
          }
        }
      }
      known.current = new Set(d.pending.map((p) => p.id));
      setData(d);
      setError(null);
      setUpdatedAt(new Date());
    } catch {
      setError("Can't reach the server. Retrying…");
    }
  }, [view, q, router, showToast, sound, chime]);

  useEffect(() => { setSeen(loadSeen()); }, []);

  useEffect(() => {
    const t = window.setTimeout(load, q ? 300 : 0);
    const iv = window.setInterval(load, POLL_MS);
    const vis = () => { if (!document.hidden) load(); };
    document.addEventListener("visibilitychange", vis);
    return () => { window.clearTimeout(t); window.clearInterval(iv); document.removeEventListener("visibilitychange", vis); };
  }, [load, q]);

  // Waiting count in the browser tab title.
  useEffect(() => {
    const n = data?.stats.pending ?? 0;
    document.title = n ? `(${n}) Requests · Leave Desk` : "Requests · Leave Desk";
  }, [data?.stats.pending]);

  // After HR has looked at the list for a few seconds, the NEW tags clear.
  useEffect(() => {
    if (!data || view !== "pending" || document.hidden) return;
    const t = window.setTimeout(() => {
      setSeen((prev) => { const s = new Set(prev); data.pending.forEach((p) => s.add(p.id)); saveSeen(s); return s; });
    }, 5000);
    return () => window.clearTimeout(t);
  }, [data, view]);

  // Is this browser already subscribed to push?
  useEffect(() => {
    if (!pushKeyAvailable || !("serviceWorker" in navigator)) return;
    navigator.serviceWorker.getRegistration("/").then((r) => r?.pushManager.getSubscription()).then((s) => { pushOn.current = !!s; }).catch(() => {});
  }, [pushKeyAvailable]);

  const counts: Record<string, number | undefined> = {
    pending: data?.stats.pending, today: data?.stats.today,
  };

  return (
    <>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold">Leave requests</h1>
          <p className="text-sm text-muted">
            {error ? <span className="font-semibold text-bad">{error}</span>
              : updatedAt ? <>Live · updated {updatedAt.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })}</> : "Loading…"}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            className="btn-ghost btn-sm"
            onClick={() => {
              if (!sound) {
                try { audio.current ??= new AudioContext(); audio.current.resume(); setSound(true); setTimeout(chime, 50); } catch { /* no audio */ }
              } else setSound(false);
            }}
          >
            {sound ? "Sound alerts on" : "Turn on sound alerts"}
          </button>
          <NotifyButton pushKeyAvailable={pushKeyAvailable} onChange={(on) => { pushOn.current = on; }} />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label="Waiting for review" value={data?.stats.pending} hot />
        <Stat label="On leave today" value={data?.stats.today} />
        <Stat label="Site staff on leave today" value={data?.stats.siteToday} />
        <Stat label="Approved starting this month" value={data?.stats.approvedMonth} />
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap gap-1.5" role="tablist">
          {VIEWS.map((v) => (
            <button key={v.id} role="tab" aria-selected={!q && view === v.id}
              onClick={() => { setQ(""); setView(v.id); }}
              className={`rounded-full border px-3.5 py-1.5 text-sm font-semibold ${!q && view === v.id ? "border-ink bg-ink text-white" : "border-line bg-white hover:bg-sunk"}`}>
              {v.label}{counts[v.id] != null && <span className="tnum ms-1.5 opacity-70">{counts[v.id]}</span>}
            </button>
          ))}
        </div>
        <input type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search name, Employee ID, site, request no."
          aria-label="Search all requests" className="input w-full max-w-xs py-2" />
      </div>

      {!data ? (
        <div className="card p-8 text-center text-muted">Loading requests…</div>
      ) : data.items.length === 0 ? (
        <div className="rounded-xl border border-dashed border-line p-8 text-center text-muted">
          {q ? `No requests match “${q}”.`
            : view === "pending" ? (data.stats.pending === 0 && data.stats.approvedMonth === 0
              ? "No leave requests yet. Add employees, give them their PINs, and new requests will appear here."
              : "All caught up. No requests are waiting.")
            : "Nothing to show here."}
        </div>
      ) : (
        <div className="grid gap-3">
          {data.items.map((r) => (
            <RequestCard key={r.id} r={r} isNew={r.status === "PENDING" && !seen.has(r.id)} onDone={(m) => { showToast(m); load(); }} />
          ))}
        </div>
      )}

      {toast && (
        <div role="status" className="fixed bottom-4 end-4 z-30 max-w-[calc(100%-2rem)] rounded-xl bg-ink px-4 py-3 font-semibold text-white shadow-xl">
          {toast}
        </div>
      )}
    </>
  );
}

function Stat({ label, value, hot }: { label: string; value?: number; hot?: boolean }) {
  return (
    <div className={`grid gap-0.5 rounded-xl border p-4 ${hot ? "border-pending bg-pending-soft" : "border-line bg-white"}`}>
      <span className="label">{label}</span>
      <b className={`tnum text-3xl font-extrabold leading-tight ${hot ? "text-pending" : ""}`}>{value ?? "–"}</b>
    </div>
  );
}

const BORDER: Record<string, string> = {
  PENDING: "border-s-pending", APPROVED: "border-s-ok", REJECTED: "border-s-bad", CANCELLED: "border-s-line",
};

function RequestCard({ r, isNew, onDone }: { r: Item; isNew: boolean; onDone: (msg: string) => void }) {
  const [note, setNote] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [confirmCancel, setConfirmCancel] = useState(false);
  const [pending, start] = useTransition();
  const left = r.daysPerYear != null && r.usedThisYear != null ? r.daysPerYear - r.usedThisYear : null;
  const missingDoc = r.requiresAttachment && r.attachments.length === 0;

  const act = (fn: () => Promise<{ ok: boolean; error?: string }>, msg: string) =>
    start(async () => {
      const res = await fn();
      if (res.ok) onDone(msg);
      else { setErr(res.error ?? "Could not save. Try again."); onDone(res.error ?? ""); }
    });

  return (
    <article className={`card grid gap-3 border-s-4 p-4 sm:p-5 ${BORDER[r.status] ?? ""}`}>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <strong className="text-[16px]">{r.name}</strong>
            <span className="rounded border border-line px-1.5 text-[11.5px] font-bold text-muted">{r.staffType === "SITE" ? "Site" : "Office"}</span>
            {isNew && <span className="rounded bg-bad px-1.5 py-0.5 text-[10.5px] font-extrabold tracking-wider text-white">NEW</span>}
          </div>
          <div className="text-sm text-muted">
            <span className="font-mono">{r.empNo}</span>
            {[r.department, r.site].filter(Boolean).map((x) => <span key={x}> · {x}</span>)}
            {r.mobile && <> · <span className="font-mono">{r.mobile}</span></>}
          </div>
        </div>
        <StatusPill status={r.status} />
      </div>

      <dl className="grid grid-cols-2 gap-x-5 gap-y-2.5 sm:grid-cols-4">
        <Fact k="Leave type" v={r.typeName} />
        <Fact k="Dates" v={`${fmtDate(r.startDate)} → ${fmtDate(r.endDate)}`} mono />
        <Fact k="Days" v={String(r.days)} mono />
        <Fact k="Submitted" v={fmtDateTime(r.createdAt)} />
        {r.coverBy && <Fact k="Covered by" v={r.coverBy} />}
        {r.contact && <Fact k="Contact on leave" v={r.contact} mono />}
        {left != null && (
          <Fact k={`${r.typeName} left this year`} v={`${left} days${r.days > left ? ` · ${r.days - left} over` : ""}`} warn={r.days > left} />
        )}
        <Fact k="Request no." v={r.refNo} mono />
      </dl>

      {r.reason && <p className="whitespace-pre-wrap break-words rounded-lg bg-sunk px-3 py-2.5">{r.reason}</p>}

      {(r.attachments.length > 0 || missingDoc) && (
        <div className="flex flex-wrap gap-2">
          {r.attachments.map((a) => (
            <a key={a.id} href={`/api/attachments/${a.id}`} target="_blank" rel="noopener"
              className="btn-ghost btn-sm">{a.type === "application/pdf" ? "Open PDF" : "View photo"}: {a.name.slice(0, 30)}</a>
          ))}
          {missingDoc && <span className="alert-warn py-1.5">No document attached yet</span>}
        </div>
      )}

      {r.status === "PENDING" ? (
        <div className="flex flex-wrap items-center gap-2">
          <input value={note} onChange={(e) => setNote(e.target.value)} maxLength={500} placeholder="Note to employee (optional)"
            aria-label={`Note to ${r.name}`} className="input min-w-[200px] flex-1 py-2" />
          <button disabled={pending} className="btn-ok" onClick={() => act(() => decideRequest(r.id, "APPROVED", note), `Approved ${r.name}'s ${r.typeName.toLowerCase()}.`)}>Approve</button>
          <button disabled={pending} className="btn-bad" onClick={() => act(() => decideRequest(r.id, "REJECTED", note), `Rejected ${r.name}'s request.`)}>Reject</button>
        </div>
      ) : (
        <div className="flex flex-wrap items-center gap-2 text-sm text-muted">
          <span>
            {r.status.charAt(0) + r.status.slice(1).toLowerCase()}
            {r.decidedAt && <> {fmtDateTime(r.decidedAt)}</>}
            {r.decidedBy && <> by {r.decidedBy}</>}
            {r.hrNote && <> · “{r.hrNote}”</>}
          </span>
          {r.status === "APPROVED" && !confirmCancel && (
            <button className="btn-ghost btn-sm" onClick={() => setConfirmCancel(true)}>Cancel this leave</button>
          )}
          {confirmCancel && (
            <span className="flex flex-wrap items-center gap-2 rounded-lg bg-bad-soft p-2">
              <input value={note} onChange={(e) => setNote(e.target.value)} placeholder="Reason for cancelling" className="input py-1.5" aria-label="Reason for cancelling" />
              <button disabled={pending} className="btn-bad btn-sm" onClick={() => act(() => cancelApproved(r.id, note), "Leave cancelled.")}>Yes, cancel leave</button>
              <button className="btn-ghost btn-sm" onClick={() => setConfirmCancel(false)}>Keep</button>
            </span>
          )}
        </div>
      )}
      {err && <p className="alert-err">{err}</p>}
    </article>
  );
}

function Fact({ k, v, mono, warn }: { k: string; v: string; mono?: boolean; warn?: boolean }) {
  return (
    <div className="min-w-0">
      <dt className="text-[11px] font-bold uppercase tracking-wider text-muted">{k}</dt>
      <dd className={`break-words font-semibold ${mono ? "tnum" : ""} ${warn ? "text-pending" : ""}`}>{v}</dd>
    </div>
  );
}

function urlB64ToUint8(base64: string) {
  const pad = "=".repeat((4 - (base64.length % 4)) % 4);
  const raw = atob((base64 + pad).replace(/-/g, "+").replace(/_/g, "/"));
  return Uint8Array.from(raw, (c) => c.charCodeAt(0));
}

/** Turns on notifications for this browser: push (works with the tab closed) when the server has keys, otherwise tab alerts. */
function NotifyButton({ pushKeyAvailable, onChange }: { pushKeyAvailable: boolean; onChange: (on: boolean) => void }) {
  const [state, setState] = useState<"unknown" | "off" | "on" | "blocked" | "unsupported">("unknown");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!("Notification" in window)) { setState("unsupported"); return; }
    if (Notification.permission === "denied") { setState("blocked"); return; }
    if (pushKeyAvailable && "serviceWorker" in navigator && "PushManager" in window) {
      navigator.serviceWorker.getRegistration("/").then((r) => r?.pushManager.getSubscription())
        .then((s) => setState(s ? "on" : "off")).catch(() => setState("off"));
    } else setState(Notification.permission === "granted" ? "on" : "off");
  }, [pushKeyAvailable]);

  async function enable() {
    setBusy(true);
    try {
      const perm = await Notification.requestPermission();
      if (perm !== "granted") { setState(perm === "denied" ? "blocked" : "off"); return; }
      if (pushKeyAvailable && "serviceWorker" in navigator && "PushManager" in window) {
        const reg = await navigator.serviceWorker.register("/sw.js", { scope: "/" });
        await navigator.serviceWorker.ready;
        const { publicKey } = await (await fetch("/api/hr/push")).json();
        const sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: urlB64ToUint8(publicKey) });
        await fetch("/api/hr/push", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(sub) });
        onChange(true);
      }
      setState("on");
    } catch {
      setState("off");
    } finally {
      setBusy(false);
    }
  }

  async function disable() {
    setBusy(true);
    try {
      const reg = await navigator.serviceWorker?.getRegistration("/");
      const sub = await reg?.pushManager.getSubscription();
      if (sub) {
        await fetch("/api/hr/push", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ endpoint: sub.endpoint }) });
        await sub.unsubscribe();
      }
      onChange(false);
      setState("off");
    } finally {
      setBusy(false);
    }
  }

  if (state === "unsupported" || state === "unknown") return null;
  if (state === "blocked") return <span className="self-center text-xs text-muted">Notifications are blocked in this browser's site settings.</span>;
  if (state === "on") {
    return pushKeyAvailable
      ? <button disabled={busy} onClick={disable} className="btn-ghost btn-sm">Notifications on · turn off</button>
      : <span className="self-center text-xs font-semibold text-ok">Tab notifications on</span>;
  }
  return <button disabled={busy} onClick={enable} className="btn-primary btn-sm">Turn on notifications</button>;
}
