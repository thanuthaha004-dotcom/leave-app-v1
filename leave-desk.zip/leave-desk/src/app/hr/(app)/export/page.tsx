import { requireHR } from "@/lib/auth";
import { addDays, todayIso } from "@/lib/dates";

export const dynamic = "force-dynamic";
export const metadata = { title: "Export" };

export default async function ExportPage() {
  await requireHR();
  const today = todayIso();
  const monthStart = today.slice(0, 8) + "01";
  const monthEnd = addDays(addDays(monthStart, 32).slice(0, 8) + "01", -1);
  return (
    <>
      <div>
        <h1 className="text-2xl font-extrabold">Export to Excel</h1>
        <p className="text-sm text-muted">Downloads a CSV file that opens in Excel, for payroll or records.</p>
      </div>
      <form action="/api/hr/export" method="get" className="card grid max-w-xl gap-4 p-5">
        <div className="grid gap-3 sm:grid-cols-2">
          <div><label className="field-label" htmlFor="from">Leave from</label><input id="from" name="from" type="date" defaultValue={monthStart} className="input" /></div>
          <div><label className="field-label" htmlFor="to">Leave to</label><input id="to" name="to" type="date" defaultValue={monthEnd} className="input" /></div>
        </div>
        <div>
          <label className="field-label" htmlFor="status">Status</label>
          <select id="status" name="status" defaultValue="APPROVED" className="input">
            <option value="APPROVED">Approved only</option>
            <option value="">All statuses</option>
            <option value="PENDING">Waiting</option>
            <option value="REJECTED">Rejected</option>
            <option value="CANCELLED">Cancelled</option>
          </select>
        </div>
        <p className="text-sm text-muted">Includes every request with at least one day inside the dates you choose.</p>
        <button className="btn-primary justify-self-start">Download leave requests</button>
      </form>
      <a href="/api/hr/export?kind=employees" className="btn-ghost justify-self-start">Download employee list</a>
    </>
  );
}
