import { requireHR } from "@/lib/auth";
import { companyName } from "@/lib/settings";
import { Logo } from "@/components/Logo";
import { HrNav } from "./HrNav";
import { hrLogout } from "../actions";

export const dynamic = "force-dynamic";

export default async function HrLayout({ children }: { children: React.ReactNode }) {
  const u = await requireHR();
  const links = [
    { href: "/hr", label: "Requests" },
    { href: "/hr/employees", label: "Employees" },
    { href: "/hr/export", label: "Export" },
    ...(u.role === "ADMIN" ? [{ href: "/hr/settings", label: "Settings" }] : []),
    { href: "/hr/account", label: "My account" },
  ];
  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-20 border-b border-line bg-white/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-x-6 gap-y-2 px-4 py-3">
          <div className="flex items-center gap-2.5">
            <Logo size={34} />
            <div className="leading-tight">
              <div className="font-extrabold">Leave Desk</div>
              <div className="text-xs text-muted">{await companyName()}</div>
            </div>
          </div>
          <HrNav links={links} />
          <div className="ms-auto flex items-center gap-3 text-sm">
            <span className="hidden text-muted sm:inline">{u.name}</span>
            <form action={hrLogout}><button className="btn-ghost btn-sm">Sign out</button></form>
          </div>
        </div>
      </header>
      <main className="mx-auto grid max-w-6xl gap-5 px-4 pb-16 pt-6">{children}</main>
    </div>
  );
}
