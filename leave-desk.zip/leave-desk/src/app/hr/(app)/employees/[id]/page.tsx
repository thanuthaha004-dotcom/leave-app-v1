import Link from "next/link";
import { notFound } from "next/navigation";
import { desc, eq } from "drizzle-orm";
import { db, employees, leaveRequests } from "@/db";
import { requireHR } from "@/lib/auth";
import { balancesFor } from "@/lib/leave";
import { fmtDate, fmtDateTime, todayIso } from "@/lib/dates";
import { StatusPill } from "@/components/StatusPill";
import { EditEmployee, ResetPin } from "../EmployeeForms";

export const dynamic = "force-dynamic";
export const metadata = { title: "Employee" };

export default async function EmployeePage({ params }: { params: Promise<{ id: string }> }) {
  await requireHR();
  const { id } = await params;
  const e = await db.query.employees.findFirst({ where: eq(employees.id, id) });
  if (!e) notFound();
  const year = Number(todayIso().slice(0, 4));
  const [balances, history] = await Promise.all([
    balancesFor(e.id, year),
    db.query.leaveRequests.findMany({ where: eq(leaveRequests.employeeId, e.id), with: { leaveType: true }, orderBy: desc(leaveRequests.startDate), limit: 100 }),
  ]);

  return (
    <>
      <div>
        <Link href="/hr/employees" className="text-sm font-semibold text-brand hover:underline">← Employees</Link>
        <h1 className="mt-1 text-2xl font-extrabold">{e.name}</h1>
        <p className="text-sm text-muted">
          <span className="font-mono">{e.empNo}</span> · {e.staffType === "SITE" ? "Site" : "Office"}
          {" · "}Last sign-in {e.lastLoginAt ? fmtDateTime(e.lastLoginAt) : "never"}
          {e.lockedUntil && e.lockedUntil > new Date() && <span className="ms-2 font-semibold text-bad">Locked after wrong PINs</span>}
        </p>
      </div>

      <div className="grid gap-4 lg:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)]">
        <EditEmployee e={{
          id: e.id, empNo: e.empNo, name: e.name, mobile: e.mobile, department: e.department, site: e.site,
          staffType: e.staffType, joiningDate: e.joiningDate, active: e.active,
        }} />
        <div className="grid content-start gap-4">
          <ResetPin id={e.id} />
          <section className="card grid gap-3 p-5">
            <h2 className="text-lg font-extrabold">Balance {year}</h2>
            {balances.length === 0 ? <p className="text-sm text-muted">No leave types with a yearly limit.</p> : (
              <table className="text-sm">
                <thead className="text-[11px] uppercase tracking-wider text-muted">
                  <tr><th className="py-1 text-left">Type</th><th className="py-1 text-right">Allowed</th><th className="py-1 text-right">Used</th><th className="py-1 text-right">Waiting</th><th className="py-1 text-right">Left</th></tr>
                </thead>
                <tbody className="tnum">
                  {balances.map((b) => (
                    <tr key={b.typeId} className="border-t border-line">
                      <td className="py-1.5 font-semibold">{b.name}</td><td className="py-1.5 text-right">{b.allowed}</td>
                      <td className="py-1.5 text-right">{b.used}</td><td className="py-1.5 text-right">{b.pending || ""}</td>
                      <td className={`py-1.5 text-right font-bold ${b.left < 0 ? "text-bad" : "text-brand"}`}>{b.left}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </section>
        </div>
      </div>

      <section className="grid gap-2">
        <h2 className="text-lg font-extrabold">Leave history</h2>
        <div className="card overflow-x-auto">
          <table className="w-full min-w-[640px] text-left text-sm">
            <thead className="border-b border-line bg-sunk/60 text-[11.5px] uppercase tracking-wider text-muted">
              <tr><th className="px-4 py-2.5">Request</th><th className="px-4 py-2.5">Type</th><th className="px-4 py-2.5">Dates</th><th className="px-4 py-2.5 text-right">Days</th><th className="px-4 py-2.5">Status</th><th className="px-4 py-2.5">HR note</th></tr>
            </thead>
            <tbody>
              {history.length === 0 && <tr><td colSpan={6} className="px-4 py-6 text-center text-muted">No leave requests yet.</td></tr>}
              {history.map((r) => (
                <tr key={r.id} className="border-b border-line last:border-0">
                  <td className="px-4 py-2.5 font-mono">{r.refNo}</td>
                  <td className="px-4 py-2.5">{r.leaveType.name}</td>
                  <td className="tnum px-4 py-2.5">{fmtDate(r.startDate)} → {fmtDate(r.endDate)}</td>
                  <td className="tnum px-4 py-2.5 text-right">{r.days}</td>
                  <td className="px-4 py-2.5"><StatusPill status={r.status} /></td>
                  <td className="px-4 py-2.5 text-muted">{r.hrNote}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </>
  );
}
