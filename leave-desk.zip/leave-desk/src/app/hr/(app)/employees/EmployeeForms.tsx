"use client";

import { noReset } from "@/components/noReset";
import { useActionState, useState, useTransition } from "react";
import { createEmployee, importEmployees, resetPin, updateEmployee, type EmpState, type ImportResult } from "../../actions";

type Emp = {
  id: string; empNo: string; name: string; mobile: string | null; department: string | null; site: string | null;
  staffType: "OFFICE" | "SITE"; joiningDate: string | null; active: boolean;
};

function Fields({ e }: { e?: Emp }) {
  return (
    <div className="grid gap-3 sm:grid-cols-2">
      <div>
        <label className="field-label" htmlFor="empNo">Employee ID *</label>
        <input id="empNo" name="empNo" required defaultValue={e?.empNo} className="input uppercase" placeholder="EMP-0142" />
      </div>
      <div>
        <label className="field-label" htmlFor="name">Full name *</label>
        <input id="name" name="name" required defaultValue={e?.name} className="input" />
      </div>
      <div>
        <label className="field-label" htmlFor="mobile">Mobile</label>
        <input id="mobile" name="mobile" type="tel" defaultValue={e?.mobile ?? ""} className="input" placeholder="05X XXX XXXX" />
      </div>
      <div>
        <label className="field-label" htmlFor="staffType">Works in</label>
        <select id="staffType" name="staffType" defaultValue={e?.staffType ?? "OFFICE"} className="input">
          <option value="OFFICE">Office</option>
          <option value="SITE">Site</option>
        </select>
      </div>
      <div>
        <label className="field-label" htmlFor="department">Department</label>
        <input id="department" name="department" defaultValue={e?.department ?? ""} className="input" />
      </div>
      <div>
        <label className="field-label" htmlFor="site">Site / project</label>
        <input id="site" name="site" defaultValue={e?.site ?? ""} className="input" />
      </div>
      <div>
        <label className="field-label" htmlFor="joiningDate">Joining date</label>
        <input id="joiningDate" name="joiningDate" type="date" defaultValue={e?.joiningDate ?? ""} className="input" />
      </div>
    </div>
  );
}

function PinSlip({ empNo, name, pin, note }: { empNo: string; name: string; pin: string; note: string }) {
  return (
    <div className="grid gap-1 rounded-lg border-2 border-dashed border-brand bg-brand-soft p-4">
      <div className="text-sm font-semibold">{name} · <span className="font-mono">{empNo}</span></div>
      <div className="flex items-baseline gap-3">
        <span className="label">PIN</span>
        <span className="font-mono text-3xl font-extrabold tracking-[0.3em] text-brand">{pin}</span>
      </div>
      <p className="text-sm text-muted">{note}</p>
    </div>
  );
}

export function AddEmployee() {
  const [open, setOpen] = useState(false);
  const [state, action, pending] = useActionState<EmpState, FormData>(createEmployee, undefined);
  const [formKey, setFormKey] = useState(0);
  return (
    <section className="card grid gap-4 p-5">
      <div className="flex items-center justify-between gap-3">
        <h2 className="text-lg font-extrabold">Add an employee</h2>
        {!open && <button className="btn-primary btn-sm" onClick={() => setOpen(true)}>Add employee</button>}
      </div>
      {state?.pin && (
        <PinSlip empNo={state.empNo!} name={state.name!} pin={state.pin}
          note="Give this PIN to the employee now. It is shown only once. They can change it after signing in." />
      )}
      {open && (
        <form key={`${formKey}-${state?.pin ?? ""}`} onSubmit={noReset(action)} className="grid gap-4">
          <Fields />
          {state?.error && <p className="alert-err">{state.error}</p>}
          <div className="flex gap-2">
            <button className="btn-primary" disabled={pending}>{pending ? "Saving…" : "Save and create PIN"}</button>
            <button type="button" className="btn-ghost" onClick={() => { setOpen(false); setFormKey((k) => k + 1); }}>Close</button>
          </div>
        </form>
      )}
    </section>
  );
}

export function ImportEmployees() {
  const [result, setResult] = useState<ImportResult | null>(null);
  const [fileName, setFileName] = useState("");
  const [pending, start] = useTransition();

  function onFile(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (!f) return;
    setFileName(f.name);
    setResult(null);
    f.text().then((text) => start(async () => setResult(await importEmployees(text))));
    e.target.value = "";
  }

  function downloadPins() {
    if (!result?.created.length) return;
    const esc = (s: string) => (/[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s);
    const csv = "﻿Employee ID,Name,PIN\r\n" + result.created.map((c) => [c.empNo, c.name, c.pin].map(esc).join(",")).join("\r\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
    const a = Object.assign(document.createElement("a"), { href: url, download: "new-employee-pins.csv" });
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  return (
    <section className="card grid gap-3 p-5">
      <h2 className="text-lg font-extrabold">Import from Excel</h2>
      <p className="text-sm text-muted">
        In Excel, use <b>File → Save As → CSV UTF-8</b>. The first row must have the column names
        <span className="font-mono"> Employee ID, Name</span> and can also have
        <span className="font-mono"> Mobile, Department, Site, Staff type, Joining date</span>.
        Existing Employee IDs are updated; new ones get a PIN.
      </p>
      <label className="btn-ghost cursor-pointer justify-self-start">
        <input type="file" accept=".csv,text/csv" onChange={onFile} className="sr-only" disabled={pending} />
        {pending ? `Importing ${fileName}…` : "Choose CSV file"}
      </label>
      {result && (
        <div className="grid gap-2">
          <p className={result.errors.length && !result.created.length && !result.updated ? "alert-err" : "alert-ok"}>
            {result.created.length} added, {result.updated} updated{result.errors.length ? `, ${result.errors.length} rows skipped` : ""}.
          </p>
          {result.created.length > 0 && (
            <div className="alert-warn grid gap-2">
              <span>Download the new PINs now. They are shown only once.</span>
              <button className="btn-primary btn-sm justify-self-start" onClick={downloadPins}>Download PIN list</button>
            </div>
          )}
          {result.errors.length > 0 && (
            <ul className="max-h-40 overflow-y-auto rounded-lg bg-sunk p-3 text-sm">
              {result.errors.slice(0, 100).map((e) => <li key={e}>{e}</li>)}
            </ul>
          )}
        </div>
      )}
    </section>
  );
}

export function EditEmployee({ e }: { e: Emp }) {
  const [state, action, pending] = useActionState<EmpState, FormData>(updateEmployee.bind(null, e.id), undefined);
  return (
    <form onSubmit={noReset(action)} className="card grid gap-4 p-5">
      <h2 className="text-lg font-extrabold">Details</h2>
      <Fields e={e} />
      <label className="flex items-center gap-2 text-sm font-semibold">
        <input type="checkbox" name="active" defaultChecked={e.active} className="h-4 w-4 accent-brand" />
        Active (can sign in and apply for leave)
      </label>
      {state?.error && <p className="alert-err">{state.error}</p>}
      {state?.saved && <p className="alert-ok">Saved.</p>}
      <button className="btn-primary justify-self-start" disabled={pending}>{pending ? "Saving…" : "Save changes"}</button>
    </form>
  );
}

export function ResetPin({ id }: { id: string }) {
  const [res, setRes] = useState<{ pin?: string; empNo?: string; name?: string; error?: string } | null>(null);
  const [confirm, setConfirm] = useState(false);
  const [pending, start] = useTransition();
  return (
    <section className="card grid gap-3 p-5">
      <h2 className="text-lg font-extrabold">PIN</h2>
      <p className="text-sm text-muted">If the employee forgot their PIN or is locked out, create a new one. Their old PIN stops working and they are signed out of all phones.</p>
      {res?.pin && <PinSlip empNo={res.empNo!} name={res.name!} pin={res.pin} note="Give this new PIN to the employee. It is shown only once." />}
      {res?.error && <p className="alert-err">{res.error}</p>}
      {!confirm ? (
        <button className="btn-ghost justify-self-start" onClick={() => setConfirm(true)}>Reset PIN</button>
      ) : (
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-sm font-semibold">Create a new PIN?</span>
          <button className="btn-primary btn-sm" disabled={pending} onClick={() => start(async () => { setRes(await resetPin(id)); setConfirm(false); })}>Yes, reset</button>
          <button className="btn-ghost btn-sm" onClick={() => setConfirm(false)}>Cancel</button>
        </div>
      )}
    </section>
  );
}
