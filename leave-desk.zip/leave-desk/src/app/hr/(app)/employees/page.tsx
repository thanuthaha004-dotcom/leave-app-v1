import Link from "next/link";
import { and, asc, count, eq, ilike, or, type SQL } from "drizzle-orm";
import { db, employees } from "@/db";
import { requireHR } from "@/lib/auth";
import { fmtDateTime } from "@/lib/dates";
import { AddEmployee, ImportEmployees } from "./EmployeeForms";

export const dynamic = "force-dynamic";
export const metadata = { title: "Employees" };
const PAGE = 50;

export default async function EmployeesPage({ searchParams }: { searchParams: Promise<{ q?: string; show?: string; page?: string }> }) {
  await requireHR();
  const sp = await searchParams;
  const q = (sp.q ?? "").trim().slice(0, 60);
  const show = sp.show === "inactive" ? "inactive" : sp.show === "all" ? "all" : "active";
  const page = Math.max(1, Number(sp.page) || 1);

  const filters: SQL[] = [];
  if (show !== "all") filters.push(eq(employees.active, show === "active"));
  if (q) {
    const like = `%${q.replace(/[%_\\]/g, (c) => "\\" + c)}%`;
    filters.push(or(ilike(employees.name, like), ilike(employees.empNo, like), ilike(employees.mobile, like), ilike(employees.site, like), ilike(employees.department, like))!);
  }
  const where = filters.length ? and(...filters) : undefined;
  const [rows, [{ total }]] = await Promise.all([
    db.select().from(employees).where(where).orderBy(asc(employees.empNo)).limit(PAGE).offset((page - 1) * PAGE),
    db.select({ total: count() }).from(employees).where(where),
  ]);
  const pages = Math.max(1, Math.ceil(total / PAGE));
  const link = (p: Record<string, string | number>) => {
    const u = new URLSearchParams({ ...(q ? { q } : {}), ...(show !== "active" ? { show } : {}), ...Object.fromEntries(Object.entries(p).map(([k, v]) => [k, String(v)])) });
    return `/hr/employees?${u}`;
  };

  return (
    <>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold">Employees</h1>
          <p className="text-sm text-muted">Everyone here can sign in with their Employee ID and PIN to apply for leave.</p>
        </div>
        <a href="/api/hr/export?kind=employees" className="btn-ghost btn-sm">Download list (Excel CSV)</a>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <AddEmployee />
        <ImportEmployees />
      </div>

      <form className="flex flex-wrap items-center gap-2" action="/hr/employees">
        <input name="q" defaultValue={q} placeholder="Search name, ID, mobile, site" aria-label="Search employees" className="input max-w-xs py-2" />
        <select name="show" defaultValue={show} aria-label="Show" className="input w-auto py-2">
          <option value="active">Active</option>
          <option value="inactive">Inactive</option>
          <option value="all">All</option>
        </select>
        <button className="btn-ghost">Search</button>
        <span className="text-sm text-muted tnum">{total} {total === 1 ? "person" : "people"}</span>
      </form>

      <div className="card overflow-x-auto">
        <table className="w-full min-w-[720px] text-left text-sm">
          <thead className="border-b border-line bg-sunk/60 text-[11.5px] uppercase tracking-wider text-muted">
            <tr>
              <th className="px-4 py-2.5">Employee ID</th><th className="px-4 py-2.5">Name</th><th className="px-4 py-2.5">Department / site</th>
              <th className="px-4 py-2.5">Type</th><th className="px-4 py-2.5">Mobile</th><th className="px-4 py-2.5">Last sign-in</th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 && (
              <tr><td colSpan={6} className="px-4 py-8 text-center text-muted">
                {q || show !== "active" ? "No employees match." : "No employees yet. Add one above or import your staff list from Excel."}
              </td></tr>
            )}
            {rows.map((e) => (
              <tr key={e.id} className="border-b border-line last:border-0 hover:bg-canvas">
                <td className="px-4 py-2.5 font-mono"><Link href={`/hr/employees/${e.id}`} className="font-semibold text-brand hover:underline">{e.empNo}</Link></td>
                <td className="px-4 py-2.5 font-semibold">{e.name}{!e.active && <span className="ms-2 rounded bg-sunk px-1.5 text-xs text-muted">Inactive</span>}</td>
                <td className="px-4 py-2.5">{[e.department, e.site].filter(Boolean).join(" · ") || <span className="text-muted">–</span>}</td>
                <td className="px-4 py-2.5">{e.staffType === "SITE" ? "Site" : "Office"}</td>
                <td className="px-4 py-2.5 font-mono">{e.mobile ?? ""}</td>
                <td className="px-4 py-2.5 text-muted">{e.lastLoginAt ? fmtDateTime(e.lastLoginAt) : "Never"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {pages > 1 && (
        <div className="flex items-center gap-3 text-sm">
          {page > 1 && <Link className="btn-ghost btn-sm" href={link({ page: page - 1 })}>Previous</Link>}
          <span className="tnum text-muted">Page {page} of {pages}</span>
          {page < pages && <Link className="btn-ghost btn-sm" href={link({ page: page + 1 })}>Next</Link>}
        </div>
      )}
    </>
  );
}
