"use client";

import { noReset } from "@/components/noReset";
import { useActionState } from "react";
import { hrLogin } from "../actions";

export function HrLoginForm() {
  const [state, action, pending] = useActionState(hrLogin, undefined);
  return (
    <form onSubmit={noReset(action)} className="grid gap-4">
      <div>
        <label htmlFor="email" className="field-label">Email</label>
        <input id="email" name="email" type="email" required autoComplete="username" className="input" />
      </div>
      <div>
        <label htmlFor="password" className="field-label">Password</label>
        <input id="password" name="password" type="password" required autoComplete="current-password" className="input" />
      </div>
      {state?.error && <p role="alert" className="alert-err">{state.error}</p>}
      <button className="btn-primary" disabled={pending}>{pending ? "Signing in…" : "Sign in"}</button>
    </form>
  );
}
