import { redirect } from "next/navigation";
import { getHR } from "@/lib/auth";
import { companyName } from "@/lib/settings";
import { Logo } from "@/components/Logo";
import { HrLoginForm } from "./HrLoginForm";

export const dynamic = "force-dynamic";
export const metadata = { title: "HR sign in" };

export default async function HrLoginPage() {
  if (await getHR()) redirect("/hr");
  return (
    <main className="mx-auto grid max-w-sm gap-5 px-4 pt-[12vh]">
      <div className="flex items-center gap-3">
        <Logo />
        <div>
          <h1 className="text-xl font-extrabold leading-tight">HR sign in</h1>
          <p className="text-sm text-muted">{await companyName()}</p>
        </div>
      </div>
      <div className="card p-5"><HrLoginForm /></div>
      <p className="text-center text-sm text-muted">Staff apply for leave at the main address, not here.</p>
    </main>
  );
}
