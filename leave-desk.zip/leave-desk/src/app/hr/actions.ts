"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { randomBytes } from "crypto";
import { and, eq, sql } from "drizzle-orm";
import { db, employees, holidays, leaveRequests, leaveTypes, users } from "@/db";
import { LOCK_AFTER, LOCK_MINUTES, requireAdmin, requireHR } from "@/lib/auth";
import { endSession, startSession } from "@/lib/session";
import { dummyVerify, generatePin, hashPassword, hashPin, verifyHash } from "@/lib/pin";
import { isIsoDate } from "@/lib/dates";
import { parseCsv } from "@/lib/csv";
import { setSetting } from "@/lib/settings";
import { audit } from "@/lib/audit";

const str = (fd: FormData, k: string, max = 200) => String(fd.get(k) ?? "").trim().slice(0, max);
const opt = (fd: FormData, k: string, max = 200) => str(fd, k, max) || null;
const tempPassword = () => randomBytes(9).toString("base64url");

/* ---------------- sign in / out ---------------- */

export async function hrLogin(_prev: { error?: string } | undefined, fd: FormData) {
  const email = str(fd, "email").toLowerCase();
  const password = String(fd.get("password") ?? "");
  const u = email ? await db.query.users.findFirst({ where: eq(users.email, email) }) : undefined;
  if (!u || !u.active) {
    await dummyVerify(password);
    return { error: "Email or password is wrong." };
  }
  if (u.lockedUntil && u.lockedUntil > new Date()) return { error: `Too many wrong tries. Try again in ${LOCK_MINUTES} minutes.` };
  if (!(await verifyHash(password, u.passwordHash))) {
    const fails = u.failedLogins + 1;
    await db.update(users).set({
      failedLogins: fails >= LOCK_AFTER ? 0 : fails,
      lockedUntil: fails >= LOCK_AFTER ? new Date(Date.now() + LOCK_MINUTES * 60_000) : null,
    }).where(eq(users.id, u.id));
    return { error: fails >= LOCK_AFTER ? `Too many wrong tries. Try again in ${LOCK_MINUTES} minutes.` : "Email or password is wrong." };
  }
  await db.update(users).set({ failedLogins: 0, lockedUntil: null, lastLoginAt: new Date() }).where(eq(users.id, u.id));
  await startSession("hr", u.id, u.tokenVersion);
  await audit("HR", u.id, "hr.login", "user", u.id);
  redirect("/hr");
}

export async function hrLogout() {
  await endSession("hr");
  redirect("/hr/login");
}

/* ---------------- decisions ---------------- */

export async function decideRequest(id: string, decision: "APPROVED" | "REJECTED", note: string) {
  const u = await requireHR();
  if (decision !== "APPROVED" && decision !== "REJECTED") return { ok: false, error: "Unknown decision." };
  const res = await db.update(leaveRequests)
    .set({ status: decision, hrNote: note.trim().slice(0, 500) || null, decidedById: u.id, decidedAt: new Date() })
    .where(and(eq(leaveRequests.id, id), eq(leaveRequests.status, "PENDING")))
    .returning({ id: leaveRequests.id, refNo: leaveRequests.refNo });
  if (!res.length) return { ok: false, error: "This request was already decided or cancelled. The list has been refreshed." };
  await audit("HR", u.id, decision === "APPROVED" ? "leave.approve" : "leave.reject", "leave_request", id, { note });
  revalidatePath("/hr");
  return { ok: true };
}

/** Cancels leave that was already approved, for example when plans change. */
export async function cancelApproved(id: string, note: string) {
  const u = await requireHR();
  const res = await db.update(leaveRequests)
    .set({ status: "CANCELLED", hrNote: note.trim().slice(0, 500) || "Cancelled by HR", decidedById: u.id, decidedAt: new Date() })
    .where(and(eq(leaveRequests.id, id), eq(leaveRequests.status, "APPROVED")))
    .returning({ id: leaveRequests.id });
  if (!res.length) return { ok: false, error: "Only approved leave can be cancelled." };
  await audit("HR", u.id, "leave.cancel", "leave_request", id, { note });
  return { ok: true };
}

/* ---------------- employees ---------------- */

type EmpInput = {
  empNo: string; name: string; mobile: string | null; department: string | null; site: string | null;
  staffType: "OFFICE" | "SITE"; joiningDate: string | null;
};

function readEmployee(fd: FormData): EmpInput | string {
  const empNo = str(fd, "empNo", 40).toUpperCase();
  const name = str(fd, "name", 120);
  if (!empNo || !name) return "Employee ID and name are required.";
  if (!/^[A-Z0-9][A-Z0-9\-_/.]*$/.test(empNo)) return "Employee ID can only use letters, numbers and - _ / .";
  const joiningDate = opt(fd, "joiningDate", 10);
  if (joiningDate && !isIsoDate(joiningDate)) return "Joining date is not a valid date.";
  return {
    empNo, name, mobile: opt(fd, "mobile", 30), department: opt(fd, "department", 80), site: opt(fd, "site", 80),
    staffType: str(fd, "staffType") === "SITE" ? "SITE" : "OFFICE", joiningDate,
  };
}

export type EmpState = { error?: string; pin?: string; empNo?: string; name?: string; saved?: boolean } | undefined;

export async function createEmployee(_prev: EmpState, fd: FormData): Promise<EmpState> {
  const u = await requireHR();
  const data = readEmployee(fd);
  if (typeof data === "string") return { error: data };
  const pin = generatePin();
  const [row] = await db.insert(employees).values({ ...data, pinHash: await hashPin(pin) })
    .onConflictDoNothing({ target: employees.empNo }).returning({ id: employees.id });
  if (!row) return { error: `Employee ID ${data.empNo} already exists.` };
  await audit("HR", u.id, "employee.create", "employee", row.id, { empNo: data.empNo });
  revalidatePath("/hr/employees");
  return { pin, empNo: data.empNo, name: data.name };
}

export async function updateEmployee(id: string, _prev: EmpState, fd: FormData): Promise<EmpState> {
  const u = await requireHR();
  const data = readEmployee(fd);
  if (typeof data === "string") return { error: data };
  const active = fd.get("active") === "on";
  try {
    await db.update(employees).set({
      ...data, active,
      // Deactivating signs the person out of every phone.
      ...(active ? {} : { tokenVersion: sql`${employees.tokenVersion} + 1` }),
    }).where(eq(employees.id, id));
  } catch {
    return { error: `Employee ID ${data.empNo} is already used by someone else.` };
  }
  await audit("HR", u.id, "employee.update", "employee", id, { ...data, active });
  revalidatePath(`/hr/employees/${id}`);
  return { saved: true };
}

export async function resetPin(id: string) {
  const u = await requireHR();
  const pin = generatePin();
  const [row] = await db.update(employees)
    .set({ pinHash: await hashPin(pin), failedLogins: 0, lockedUntil: null, tokenVersion: sql`${employees.tokenVersion} + 1` })
    .where(eq(employees.id, id)).returning({ empNo: employees.empNo, name: employees.name });
  if (!row) return { error: "Employee not found." };
  await audit("HR", u.id, "employee.reset_pin", "employee", id);
  return { pin, empNo: row.empNo, name: row.name };
}

const HEADER_ALIASES: Record<string, keyof EmpInput> = {
  "employee id": "empNo", "employee_id": "empNo", "emp id": "empNo", "emp no": "empNo", "id": "empNo", "staff id": "empNo",
  "name": "name", "full name": "name", "employee name": "name",
  "mobile": "mobile", "phone": "mobile", "mobile number": "mobile",
  "department": "department", "dept": "department",
  "site": "site", "location": "site", "project": "site",
  "staff type": "staffType", "staff_type": "staffType", "type": "staffType",
  "joining date": "joiningDate", "joining_date": "joiningDate", "date of joining": "joiningDate", "doj": "joiningDate",
};

export type ImportResult = {
  created: { empNo: string; name: string; pin: string }[];
  updated: number;
  errors: string[];
};

/** Adds new employees and updates existing ones from a CSV. New people get a PIN, returned once. */
export async function importEmployees(csvText: string): Promise<ImportResult> {
  const u = await requireHR();
  const rows = parseCsv(csvText);
  const result: ImportResult = { created: [], updated: 0, errors: [] };
  if (rows.length < 2) return { ...result, errors: ["The file needs a header row and at least one employee."] };
  const cols = rows[0].map((h) => HEADER_ALIASES[h.trim().toLowerCase()]);
  if (!cols.includes("empNo") || !cols.includes("name")) {
    return { ...result, errors: ["The header row must include 'Employee ID' and 'Name' columns."] };
  }
  if (rows.length > 5001) return { ...result, errors: ["Import up to 5,000 employees at a time."] };

  for (let i = 1; i < rows.length; i++) {
    const rec: Partial<Record<keyof EmpInput, string>> = {};
    rows[i].forEach((v, j) => { if (cols[j]) rec[cols[j]!] = v.trim(); });
    const fd = new FormData();
    for (const [k, v] of Object.entries(rec)) fd.set(k, v ?? "");
    const st = (rec.staffType ?? "").toUpperCase();
    fd.set("staffType", st.startsWith("SITE") || st.startsWith("LAB") ? "SITE" : "OFFICE");
    const jd = rec.joiningDate ?? "";
    const m = jd.match(/^(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})$/); // 18/10/2026 → 2026-10-18
    fd.set("joiningDate", m ? `${m[3]}-${m[2].padStart(2, "0")}-${m[1].padStart(2, "0")}` : jd);
    const data = readEmployee(fd);
    if (typeof data === "string") { result.errors.push(`Row ${i + 1}: ${data}`); continue; }

    const existing = await db.query.employees.findFirst({ where: eq(employees.empNo, data.empNo), columns: { id: true } });
    if (existing) {
      await db.update(employees).set(data).where(eq(employees.id, existing.id));
      result.updated++;
    } else {
      const pin = generatePin();
      await db.insert(employees).values({ ...data, pinHash: await hashPin(pin) });
      result.created.push({ empNo: data.empNo, name: data.name, pin });
    }
  }
  await audit("HR", u.id, "employee.import", "employee", null, { created: result.created.length, updated: result.updated, errors: result.errors.length });
  revalidatePath("/hr/employees");
  return result;
}

/* ---------------- settings (administrators) ---------------- */

export async function saveGeneral(fd: FormData) {
  const u = await requireAdmin();
  const name = str(fd, "company_name", 120);
  if (name) await setSetting("company_name", name);
  for (const t of ["OFFICE", "SITE"]) {
    const days = fd.getAll(`weekend_${t}`).map(String).filter((d) => /^[0-6]$/.test(d));
    await setSetting(`weekend_${t}`, days.join(","));
  }
  await audit("HR", u.id, "settings.general", "settings", null);
  revalidatePath("/hr/settings");
}

export async function saveLeaveType(id: string, fd: FormData) {
  const u = await requireAdmin();
  const days = str(fd, "daysPerYear", 4);
  const names: Record<string, string> = {};
  for (const l of ["ar", "hi", "ur", "ml"]) { const v = str(fd, `name_${l}`, 60); if (v) names[l] = v; }
  await db.update(leaveTypes).set({
    name: str(fd, "name", 60) || "Leave",
    names,
    daysPerYear: /^\d+$/.test(days) ? Number(days) : null,
    countMode: str(fd, "countMode") === "WORKING" ? "WORKING" : "CALENDAR",
    requiresAttachment: fd.get("requiresAttachment") === "on",
    active: fd.get("active") === "on",
    sortOrder: Number(str(fd, "sortOrder", 3)) || 0,
  }).where(eq(leaveTypes.id, id));
  await audit("HR", u.id, "settings.leave_type", "leave_type", id);
  revalidatePath("/hr/settings");
}

export async function addLeaveType(fd: FormData) {
  const u = await requireAdmin();
  const name = str(fd, "name", 60);
  if (!name) return;
  const code = name.toUpperCase().replace(/[^A-Z0-9]+/g, "_").replace(/^_|_$/g, "").slice(0, 30) || "TYPE";
  await db.insert(leaveTypes).values({ code: `${code}_${Date.now().toString(36).toUpperCase()}`, name, sortOrder: 50 });
  await audit("HR", u.id, "settings.leave_type_add", "leave_type", null, { name });
  revalidatePath("/hr/settings");
}

export async function addHoliday(fd: FormData) {
  const u = await requireAdmin();
  const date = str(fd, "date", 10);
  const name = str(fd, "name", 80);
  if (!isIsoDate(date) || !name) return;
  await db.insert(holidays).values({ date, name }).onConflictDoUpdate({ target: holidays.date, set: { name } });
  await audit("HR", u.id, "settings.holiday_add", "holiday", null, { date, name });
  revalidatePath("/hr/settings");
}

export async function deleteHoliday(id: string) {
  const u = await requireAdmin();
  await db.delete(holidays).where(eq(holidays.id, id));
  await audit("HR", u.id, "settings.holiday_delete", "holiday", id);
  revalidatePath("/hr/settings");
}

export type UserState = { error?: string; email?: string; password?: string } | undefined;

export async function createUser(_prev: UserState, fd: FormData): Promise<UserState> {
  const u = await requireAdmin();
  const email = str(fd, "email", 120).toLowerCase();
  const name = str(fd, "name", 80);
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email) || !name) return { error: "Enter a name and a valid email." };
  const password = tempPassword();
  const [row] = await db.insert(users).values({
    email, name, role: str(fd, "role") === "ADMIN" ? "ADMIN" : "HR", passwordHash: await hashPassword(password),
  }).onConflictDoNothing({ target: users.email }).returning({ id: users.id });
  if (!row) return { error: `${email} already has an account.` };
  await audit("HR", u.id, "user.create", "user", row.id, { email });
  revalidatePath("/hr/settings");
  return { email, password };
}

export async function setUserActive(id: string, active: boolean) {
  const u = await requireAdmin();
  if (id === u.id) return;
  await db.update(users).set({ active, tokenVersion: sql`${users.tokenVersion} + 1` }).where(eq(users.id, id));
  await audit("HR", u.id, active ? "user.activate" : "user.deactivate", "user", id);
  revalidatePath("/hr/settings");
}

export async function resetUserPassword(id: string) {
  const u = await requireAdmin();
  const password = tempPassword();
  const [row] = await db.update(users)
    .set({ passwordHash: await hashPassword(password), failedLogins: 0, lockedUntil: null, tokenVersion: sql`${users.tokenVersion} + 1` })
    .where(eq(users.id, id)).returning({ email: users.email });
  await audit("HR", u.id, "user.reset_password", "user", id);
  return row ? { email: row.email, password } : { error: "User not found." };
}

/* ---------------- own account ---------------- */

export async function changePassword(_prev: { error?: string; ok?: boolean } | undefined, fd: FormData) {
  const u = await requireHR();
  const current = String(fd.get("current") ?? "");
  const next = String(fd.get("next") ?? "");
  if (next.length < 10) return { error: "Use at least 10 characters for the new password." };
  if (next !== String(fd.get("again") ?? "")) return { error: "The two new passwords are not the same." };
  if (!(await verifyHash(current, u.passwordHash))) return { error: "Current password is wrong." };
  const [row] = await db.update(users)
    .set({ passwordHash: await hashPassword(next), tokenVersion: sql`${users.tokenVersion} + 1` })
    .where(eq(users.id, u.id)).returning({ v: users.tokenVersion });
  await startSession("hr", u.id, row.v);
  await audit("HR", u.id, "user.change_password", "user", u.id);
  return { ok: true };
}

export async function setEmailAlerts(on: boolean) {
  const u = await requireHR();
  await db.update(users).set({ emailAlerts: on }).where(eq(users.id, u.id));
  revalidatePath("/hr/account");
}
