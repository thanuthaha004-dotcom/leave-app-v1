import { z } from "zod";
import { getHR } from "@/lib/auth";
import { pushEnabled, removePushSubscription, savePushSubscription } from "@/lib/notify";

export const dynamic = "force-dynamic";

const Sub = z.object({ endpoint: z.string().url().max(1000), keys: z.object({ p256dh: z.string().max(200), auth: z.string().max(100) }) });

/** The browser asks for the public key before subscribing to push notifications. */
export async function GET() {
  if (!(await getHR())) return Response.json({ error: "signed_out" }, { status: 401 });
  return Response.json({ enabled: pushEnabled(), publicKey: process.env.VAPID_PUBLIC_KEY ?? null });
}

export async function POST(req: Request) {
  const hr = await getHR();
  if (!hr) return Response.json({ error: "signed_out" }, { status: 401 });
  const parsed = Sub.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return Response.json({ error: "bad_subscription" }, { status: 400 });
  await savePushSubscription(hr.id, parsed.data);
  return Response.json({ ok: true });
}

export async function DELETE(req: Request) {
  const hr = await getHR();
  if (!hr) return Response.json({ error: "signed_out" }, { status: 401 });
  const body = await req.json().catch(() => null);
  if (typeof body?.endpoint === "string") await removePushSubscription(hr.id, body.endpoint);
  return Response.json({ ok: true });
}
