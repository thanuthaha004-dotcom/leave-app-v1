import { NextRequest } from "next/server";
import { and, asc, eq, gte, lte, type SQL } from "drizzle-orm";
import { db, employees, leaveRequests, leaveTypes, users } from "@/db";
import { getHR } from "@/lib/auth";
import { toCsv } from "@/lib/csv";
import { fmtDateTime, isIsoDate, todayIso } from "@/lib/dates";
import { audit } from "@/lib/audit";

export const dynamic = "force-dynamic";

/** Downloads leave requests or the employee list as a CSV that opens in Excel. */
export async function GET(req: NextRequest) {
  const hr = await getHR();
  if (!hr) return new Response("Sign in first.", { status: 401 });
  const p = req.nextUrl.searchParams;
  const today = todayIso();

  if (p.get("kind") === "employees") {
    const rows = await db.select().from(employees).orderBy(asc(employees.empNo));
    await audit("HR", hr.id, "export.employees", "employee", null, { count: rows.length });
    return csvResponse(`employees-${today}.csv`, [
      ["Employee ID", "Name", "Mobile", "Department", "Site", "Staff type", "Joining date", "Active", "Last sign-in"],
      ...rows.map((e) => [e.empNo, e.name, e.mobile, e.department, e.site, e.staffType, e.joiningDate, e.active ? "Yes" : "No", fmtDateTime(e.lastLoginAt)]),
    ]);
  }

  const from = p.get("from") ?? "";
  const to = p.get("to") ?? "";
  const status = p.get("status") ?? "";
  const filters: SQL[] = [];
  if (isIsoDate(from)) filters.push(gte(leaveRequests.endDate, from));
  if (isIsoDate(to)) filters.push(lte(leaveRequests.startDate, to));
  if (["PENDING", "APPROVED", "REJECTED", "CANCELLED"].includes(status)) {
    filters.push(eq(leaveRequests.status, status as "PENDING"));
  }
  const rows = await db
    .select({ r: leaveRequests, e: employees, typeName: leaveTypes.name, decidedBy: users.name })
    .from(leaveRequests)
    .innerJoin(employees, eq(employees.id, leaveRequests.employeeId))
    .innerJoin(leaveTypes, eq(leaveTypes.id, leaveRequests.leaveTypeId))
    .leftJoin(users, eq(users.id, leaveRequests.decidedById))
    .where(filters.length ? and(...filters) : undefined)
    .orderBy(asc(leaveRequests.startDate));
  await audit("HR", hr.id, "export.leave", "leave_request", null, { from, to, status, count: rows.length });
  return csvResponse(`leave-requests-${today}.csv`, [
    ["Request no.", "Employee ID", "Name", "Department", "Site", "Staff type", "Leave type", "From", "To", "Days", "Status",
      "Reason", "Covered by", "HR note", "Decided by", "Decided at", "Submitted at"],
    ...rows.map(({ r, e, typeName, decidedBy }) => [
      r.refNo, e.empNo, e.name, e.department, e.site, e.staffType, typeName, r.startDate, r.endDate, r.days, r.status,
      r.reason, r.coverBy, r.hrNote, decidedBy, fmtDateTime(r.decidedAt), fmtDateTime(r.createdAt),
    ]),
  ]);
}

function csvResponse(filename: string, rows: (string | number | null | undefined)[][]) {
  return new Response(toCsv(rows), {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${filename}"`,
      "Cache-Control": "no-store",
    },
  });
}
