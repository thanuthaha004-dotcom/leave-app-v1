import { NextRequest } from "next/server";
import { and, asc, desc, eq, gt, gte, ilike, inArray, lte, or, sql, type SQL } from "drizzle-orm";
import { db, employees, leaveRequests, leaveTypes, users } from "@/db";
import { getHR } from "@/lib/auth";
import { addDays, todayIso } from "@/lib/dates";

export const dynamic = "force-dynamic";

/** Data for the HR dashboard. The page calls this every 15 seconds. */
export async function GET(req: NextRequest) {
  if (!(await getHR())) return Response.json({ error: "signed_out" }, { status: 401 });
  const view = req.nextUrl.searchParams.get("view") ?? "pending";
  const q = (req.nextUrl.searchParams.get("q") ?? "").trim().slice(0, 60);
  const today = todayIso();
  const month = today.slice(0, 7);

  const onLeaveToday = and(eq(leaveRequests.status, "APPROVED"), lte(leaveRequests.startDate, today), gte(leaveRequests.endDate, today));
  let where: SQL | undefined;
  let order = [desc(leaveRequests.createdAt)];
  if (q) {
    const like = `%${q.replace(/[%_\\]/g, (c) => "\\" + c)}%`;
    where = or(ilike(employees.name, like), ilike(employees.empNo, like), ilike(leaveRequests.refNo, like), ilike(employees.site, like), ilike(employees.department, like));
  } else if (view === "today") {
    where = onLeaveToday;
    order = [asc(leaveRequests.endDate)];
  } else if (view === "upcoming") {
    where = and(eq(leaveRequests.status, "APPROVED"), gt(leaveRequests.startDate, today), lte(leaveRequests.startDate, addDays(today, 30)));
    order = [asc(leaveRequests.startDate)];
  } else if (view === "decided") {
    where = inArray(leaveRequests.status, ["APPROVED", "REJECTED", "CANCELLED"]);
    order = [desc(leaveRequests.decidedAt)];
  } else {
    where = eq(leaveRequests.status, "PENDING");
  }

  const rows = await db
    .select({
      id: leaveRequests.id, refNo: leaveRequests.refNo, status: leaveRequests.status,
      startDate: leaveRequests.startDate, endDate: leaveRequests.endDate, days: leaveRequests.days,
      reason: leaveRequests.reason, coverBy: leaveRequests.coverBy, contact: leaveRequests.contact,
      hrNote: leaveRequests.hrNote, createdAt: leaveRequests.createdAt, decidedAt: leaveRequests.decidedAt,
      decidedBy: users.name,
      employeeId: employees.id, empNo: employees.empNo, name: employees.name, mobile: employees.mobile,
      department: employees.department, site: employees.site, staffType: employees.staffType,
      leaveTypeId: leaveTypes.id, typeName: leaveTypes.name, requiresAttachment: leaveTypes.requiresAttachment, daysPerYear: leaveTypes.daysPerYear,
      attachments: sql<{ id: string; name: string; type: string }[]>`coalesce((
        select json_agg(json_build_object('id', a.id, 'name', a.original_name, 'type', a.mime_type))
        from attachments a where a.request_id = ${leaveRequests.id}), '[]'::json)`,
    })
    .from(leaveRequests)
    .innerJoin(employees, eq(employees.id, leaveRequests.employeeId))
    .innerJoin(leaveTypes, eq(leaveTypes.id, leaveRequests.leaveTypeId))
    .leftJoin(users, eq(users.id, leaveRequests.decidedById))
    .where(where)
    .orderBy(...order)
    .limit(q ? 100 : 300);

  // For waiting requests, show how many days of that leave type the person has already used this year.
  const pendingLimited = rows.filter((r) => r.status === "PENDING" && r.daysPerYear != null);
  const used = new Map<string, number>();
  if (pendingLimited.length) {
    const sums = await db.select({
      employeeId: leaveRequests.employeeId, leaveTypeId: leaveRequests.leaveTypeId,
      year: sql<string>`to_char(${leaveRequests.startDate}, 'YYYY')`, total: sql<number>`sum(${leaveRequests.days})::int`,
    }).from(leaveRequests)
      .where(and(eq(leaveRequests.status, "APPROVED"), inArray(leaveRequests.employeeId, [...new Set(pendingLimited.map((r) => r.employeeId))])))
      .groupBy(leaveRequests.employeeId, leaveRequests.leaveTypeId, sql`to_char(${leaveRequests.startDate}, 'YYYY')`);
    for (const s of sums) used.set(`${s.employeeId}|${s.leaveTypeId}|${s.year}`, s.total);
  }

  const [stats] = await db.select({
    pending: sql<number>`count(*) filter (where ${leaveRequests.status} = 'PENDING')::int`,
    today: sql<number>`count(*) filter (where ${onLeaveToday})::int`,
    siteToday: sql<number>`count(*) filter (where ${onLeaveToday} and ${employees.staffType} = 'SITE')::int`,
    approvedMonth: sql<number>`count(*) filter (where ${leaveRequests.status} = 'APPROVED' and to_char(${leaveRequests.startDate}, 'YYYY-MM') = ${month})::int`,
  }).from(leaveRequests).innerJoin(employees, eq(employees.id, leaveRequests.employeeId));

  const pendingIds = (await db.select({ id: leaveRequests.id, name: employees.name }).from(leaveRequests)
    .innerJoin(employees, eq(employees.id, leaveRequests.employeeId))
    .where(eq(leaveRequests.status, "PENDING")).orderBy(desc(leaveRequests.createdAt)).limit(500));

  return Response.json({
    today,
    stats,
    pending: pendingIds,
    items: rows.map(({ employeeId, leaveTypeId, ...r }) => ({
      ...r,
      usedThisYear: r.status === "PENDING" && r.daysPerYear != null
        ? used.get(`${employeeId}|${leaveTypeId}|${r.startDate.slice(0, 4)}`) ?? 0
        : null,
      employeeId,
    })),
  });
}
