import { eq } from "drizzle-orm";
import { attachments, db } from "@/db";
import { getHR, getStaff } from "@/lib/auth";
import { readUpload } from "@/lib/uploads";

export const dynamic = "force-dynamic";

/** HR can open any attachment; staff can open only their own. */
export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const a = await db.query.attachments.findFirst({ where: eq(attachments.id, id), with: { request: true } });
  if (!a) return new Response("Not found", { status: 404 });
  const hr = await getHR();
  const staff = hr ? null : await getStaff();
  if (!hr && (!staff || staff.id !== a.request.employeeId)) return new Response("Not found", { status: 404 });
  try {
    const data = await readUpload(a.storedName);
    return new Response(new Uint8Array(data), {
      headers: {
        "Content-Type": a.mimeType,
        "Content-Disposition": `inline; filename="${encodeURIComponent(a.originalName)}"`,
        "Cache-Control": "private, no-store",
        ...(a.mimeType.startsWith("image/") ? { "Content-Security-Policy": "default-src 'none'; img-src 'self'; style-src 'unsafe-inline'" } : {}),
      },
    });
  } catch {
    return new Response("The file is missing on the server.", { status: 410 });
  }
}
