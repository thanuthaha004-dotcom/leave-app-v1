"use server";

import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { after } from "next/server";
import { and, eq, gte, inArray, lte, sql } from "drizzle-orm";
import { attachments, db, employees, leaveRequests, leaveTypes } from "@/db";
import { LOCK_AFTER, LOCK_MINUTES, getStaff, requireStaff } from "@/lib/auth";
import { endSession, startSession } from "@/lib/session";
import { LANG_COOKIE, isLang, type Key } from "@/lib/i18n";
import { addDays, isIsoDate, todayIso } from "@/lib/dates";
import { balancesFor, daysForRequest, newRefNo } from "@/lib/leave";
import { dummyVerify, hashPin, isValidPin, verifyHash } from "@/lib/pin";
import { isAllowedUpload, saveUpload } from "@/lib/uploads";
import { notifyNewRequest } from "@/lib/notify";
import { audit } from "@/lib/audit";

export async function setLanguage(lang: string) {
  if (!isLang(lang)) return;
  (await cookies()).set(LANG_COOKIE, lang, { path: "/", maxAge: 60 * 60 * 24 * 365, sameSite: "lax" });
}

/* ---------------- sign in / out ---------------- */

export type LoginState = { error?: Key } | undefined;

export async function staffLogin(_prev: LoginState, fd: FormData): Promise<LoginState> {
  const empNo = String(fd.get("empNo") ?? "").trim().toUpperCase();
  const pin = String(fd.get("pin") ?? "").trim();
  if (!empNo || !pin) return { error: "errLogin" };

  const e = await db.query.employees.findFirst({ where: eq(employees.empNo, empNo) });
  if (!e || !e.active) {
    await dummyVerify(pin); // takes the same time either way, so IDs can't be guessed
    return { error: "errLogin" };
  }
  if (e.lockedUntil && e.lockedUntil > new Date()) return { error: "errLocked" };

  if (!(await verifyHash(pin, e.pinHash))) {
    const fails = e.failedLogins + 1;
    await db.update(employees).set({
      failedLogins: fails >= LOCK_AFTER ? 0 : fails,
      lockedUntil: fails >= LOCK_AFTER ? new Date(Date.now() + LOCK_MINUTES * 60_000) : null,
    }).where(eq(employees.id, e.id));
    if (fails >= LOCK_AFTER) await audit("SYSTEM", null, "staff.locked", "employee", e.id);
    return { error: fails >= LOCK_AFTER ? "errLocked" : "errLogin" };
  }

  await db.update(employees).set({ failedLogins: 0, lockedUntil: null, lastLoginAt: new Date() }).where(eq(employees.id, e.id));
  await startSession("staff", e.id, e.tokenVersion);
  redirect("/me");
}

export async function staffLogout() {
  await endSession("staff");
  redirect("/login");
}

/* ---------------- apply ---------------- */

export type ApplyState =
  | { ok: true; refNo: string; warn?: { type: string; left: number } }
  | { ok: false; error: Key; ref?: string }
  | undefined;

const clip = (v: FormDataEntryValue | null, n: number) => String(v ?? "").trim().slice(0, n) || null;

export async function submitLeave(_prev: ApplyState, fd: FormData): Promise<ApplyState> {
  const emp = await getStaff();
  if (!emp) redirect("/login");

  const typeId = String(fd.get("leaveTypeId") ?? "");
  const start = String(fd.get("startDate") ?? "");
  const end = String(fd.get("endDate") ?? "");
  if (!typeId || !isIsoDate(start) || !isIsoDate(end)) return { ok: false, error: "errMissing" };
  if (end < start) return { ok: false, error: "errDates" };
  const today = todayIso();
  if (start < addDays(today, -60)) return { ok: false, error: "errPast" };
  if (end > addDays(today, 366)) return { ok: false, error: "errFuture" };

  const type = await db.query.leaveTypes.findFirst({ where: and(eq(leaveTypes.id, typeId), eq(leaveTypes.active, true)) });
  if (!type) return { ok: false, error: "errMissing" };

  const raw = fd.get("attachment");
  const file = raw instanceof File && raw.size > 0 ? raw : null;
  if (file && !isAllowedUpload(file)) return { ok: false, error: "errFile" };

  const days = await daysForRequest(emp, type, start, end);
  if (days <= 0) return { ok: false, error: "errZero" };

  const [clash] = await db.select({ refNo: leaveRequests.refNo }).from(leaveRequests).where(and(
    eq(leaveRequests.employeeId, emp.id),
    inArray(leaveRequests.status, ["PENDING", "APPROVED"]),
    lte(leaveRequests.startDate, end),
    gte(leaveRequests.endDate, start),
  )).limit(1);
  if (clash) return { ok: false, error: "errOverlap", ref: clash.refNo };

  let refNo = "";
  let requestId = "";
  try {
    for (let attempt = 0; attempt < 5 && !requestId; attempt++) {
      refNo = newRefNo(today);
      const [row] = await db.insert(leaveRequests).values({
        refNo, employeeId: emp.id, leaveTypeId: type.id, startDate: start, endDate: end, days,
        reason: clip(fd.get("reason"), 1000), coverBy: clip(fd.get("coverBy"), 120), contact: clip(fd.get("contact"), 40),
      }).onConflictDoNothing({ target: leaveRequests.refNo }).returning({ id: leaveRequests.id });
      if (row) requestId = row.id;
    }
    if (!requestId) return { ok: false, error: "errGeneric" };
    if (file) {
      const storedName = await saveUpload(file);
      await db.insert(attachments).values({
        requestId, storedName, originalName: file.name.slice(0, 200) || "document", mimeType: file.type, size: file.size,
      });
    }
  } catch (e) {
    console.error("Leave submit failed", e);
    return { ok: false, error: "errGeneric" };
  }

  await audit("STAFF", emp.id, "leave.submit", "leave_request", requestId, { refNo, type: type.code, start, end, days });
  after(() => notifyNewRequest(requestId).catch((e) => console.error("Notify failed", e)));

  let warn: { type: string; left: number } | undefined;
  if (type.daysPerYear != null) {
    const b = (await balancesFor(emp.id, Number(start.slice(0, 4)))).find((x) => x.typeId === type.id);
    if (b && b.used + b.pending > b.allowed) warn = { type: type.id, left: Math.max(0, b.left) };
  }
  revalidatePath("/me");
  return { ok: true, refNo, warn };
}

export async function cancelLeave(requestId: string) {
  const emp = await requireStaff();
  const res = await db.update(leaveRequests)
    .set({ status: "CANCELLED" })
    .where(and(eq(leaveRequests.id, requestId), eq(leaveRequests.employeeId, emp.id), eq(leaveRequests.status, "PENDING")))
    .returning({ id: leaveRequests.id });
  if (res.length) await audit("STAFF", emp.id, "leave.cancel", "leave_request", requestId);
  revalidatePath("/me");
}

/* ---------------- change PIN ---------------- */

export type PinState = { ok?: boolean; error?: Key } | undefined;

export async function changePin(_prev: PinState, fd: FormData): Promise<PinState> {
  const emp = await requireStaff();
  const current = String(fd.get("current") ?? "");
  const next = String(fd.get("next") ?? "");
  const again = String(fd.get("again") ?? "");
  if (!isValidPin(next)) return { error: "errPinFormat" };
  if (next !== again) return { error: "errPinMatch" };
  if (!(await verifyHash(current, emp.pinHash))) return { error: "errPinWrong" };
  const [row] = await db.update(employees)
    .set({ pinHash: await hashPin(next), tokenVersion: sql`${employees.tokenVersion} + 1` })
    .where(eq(employees.id, emp.id))
    .returning({ v: employees.tokenVersion });
  await startSession("staff", emp.id, row.v); // keep this phone signed in, sign out everywhere else
  await audit("STAFF", emp.id, "pin.change", "employee", emp.id);
  return { ok: true };
}
