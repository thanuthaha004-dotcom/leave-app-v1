import { and, eq, gte, lte } from "drizzle-orm";
import { db, holidays, leaveTypes } from "@/db";
import { requireStaff } from "@/lib/auth";
import { getT } from "@/lib/lang";
import { companyName, getSettings } from "@/lib/settings";
import { balancesFor, parseWeekend, typeLabel } from "@/lib/leave";
import { addDays, todayIso } from "@/lib/dates";
import { StaffHeader } from "../StaffHeader";
import { ApplyForm } from "./ApplyForm";

export const dynamic = "force-dynamic";
export const metadata = { title: "Apply for leave" };

export default async function ApplyPage() {
  const emp = await requireStaff();
  const { lang, t } = await getT();
  const today = todayIso();
  const [types, s, hs, balances] = await Promise.all([
    db.select().from(leaveTypes).where(eq(leaveTypes.active, true)).orderBy(leaveTypes.sortOrder),
    getSettings(),
    db.select({ date: holidays.date }).from(holidays).where(and(gte(holidays.date, addDays(today, -60)), lte(holidays.date, addDays(today, 400)))),
    balancesFor(emp.id, Number(today.slice(0, 4))),
  ]);
  const keys = [
    "leaveType", "from", "to", "daysCount", "reason", "reasonPh", "cover", "contact", "attachment", "attachmentReq",
    "attachmentOpt", "submit", "sending", "back", "errMissing", "errDates", "errPast", "errFuture", "errZero", "errOverlap",
    "errFile", "errGeneric", "okTitle", "okMsg", "overBalance", "myRequests", "apply",
  ] as const;
  const text = Object.fromEntries(keys.map((k) => [k, t(k)])) as Record<(typeof keys)[number], string>;

  return (
    <>
      <StaffHeader lang={lang} t={t} company={await companyName()} />
      <h1 className="text-2xl font-extrabold">{t("apply")}</h1>
      <ApplyForm
        text={text}
        today={today}
        weekend={parseWeekend(s[`weekend_${emp.staffType}`])}
        holidays={hs.map((h) => h.date)}
        types={types.map((ty) => ({
          id: ty.id,
          label: typeLabel(ty, lang),
          countMode: ty.countMode,
          requiresAttachment: ty.requiresAttachment,
          left: balances.find((b) => b.typeId === ty.id)?.left ?? null,
        }))}
      />
    </>
  );
}
