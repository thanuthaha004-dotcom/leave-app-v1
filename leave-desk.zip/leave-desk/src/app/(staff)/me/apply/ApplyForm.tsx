"use client";

import Link from "next/link";
import { useActionState, useMemo, useRef, useState, startTransition } from "react";
import { submitLeave, type ApplyState } from "../../actions";
import { countLeaveDays } from "@/lib/days";
import { addDays } from "@/lib/dates";

type Type = { id: string; label: string; countMode: "CALENDAR" | "WORKING"; requiresAttachment: boolean; left: number | null };
type Props = {
  text: Record<string, string>;
  today: string;
  weekend: number[];
  holidays: string[];
  types: Type[];
};

const fill = (s: string, vars: Record<string, string | number>) =>
  Object.entries(vars).reduce((acc, [k, v]) => acc.replaceAll(`{${k}}`, String(v)), s);

/** Phone photos are often 4–8 MB. Shrink them before upload so site staff on mobile data can send them. */
async function shrinkImage(file: File): Promise<File> {
  if (!/^image\/(jpeg|png|webp)$/.test(file.type) || file.size < 600_000) return file;
  try {
    const bmp = await createImageBitmap(file);
    const scale = Math.min(1, 1600 / Math.max(bmp.width, bmp.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.round(bmp.width * scale);
    canvas.height = Math.round(bmp.height * scale);
    canvas.getContext("2d")!.drawImage(bmp, 0, 0, canvas.width, canvas.height);
    const blob = await new Promise<Blob | null>((r) => canvas.toBlob(r, "image/jpeg", 0.82));
    return blob ? new File([blob], file.name.replace(/\.\w+$/, "") + ".jpg", { type: "image/jpeg" }) : file;
  } catch {
    return file;
  }
}

export function ApplyForm({ text, today, weekend, holidays, types }: Props) {
  const [state, action, pending] = useActionState<ApplyState, FormData>(submitLeave, undefined);
  const [typeId, setTypeId] = useState("");
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");
  const [preparing, setPreparing] = useState(false);
  const formRef = useRef<HTMLFormElement>(null);
  const type = types.find((x) => x.id === typeId);
  const holidaySet = useMemo(() => new Set(holidays), [holidays]);
  const days = type && start && end ? countLeaveDays(start, end, type.countMode, weekend, holidaySet) : 0;
  const busy = pending || preparing;

  if (state?.ok) {
    const warnType = state.warn ? types.find((x) => x.id === state.warn!.type) : null;
    return (
      <div className="card grid justify-items-center gap-3 p-6 text-center">
        <div className="grid h-16 w-16 place-items-center rounded-full bg-ok-soft text-3xl font-extrabold text-ok" aria-hidden>✓</div>
        <h2 className="text-xl font-extrabold">{text.okTitle}</h2>
        <p>{text.okMsg}</p>
        <div dir="ltr" className="rounded-lg bg-sunk px-4 py-2 font-mono text-xl font-bold">{state.refNo}</div>
        {warnType && <p className="alert-warn">{fill(text.overBalance, { type: warnType.label, n: state.warn!.left })}</p>}
        <Link href="/me" className="btn-primary btn-lg mt-2">{text.myRequests}</Link>
      </div>
    );
  }

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const f = fd.get("attachment");
    if (f instanceof File && f.size > 0) {
      setPreparing(true);
      fd.set("attachment", await shrinkImage(f));
      setPreparing(false);
    }
    startTransition(() => action(fd));
  }

  const error = state && !state.ok ? fill(text[state.error] ?? text.errGeneric, { ref: state.ref ?? "" }) : null;

  return (
    <form ref={formRef} onSubmit={onSubmit} className="card grid gap-5 p-5" noValidate>
      <fieldset className="grid gap-2">
        <legend className="field-label">{text.leaveType} <span className="text-bad">*</span></legend>
        <div className="grid grid-cols-2 gap-2">
          {types.map((ty) => (
            <label key={ty.id} className="relative">
              <input type="radio" name="leaveTypeId" value={ty.id} checked={typeId === ty.id}
                onChange={() => setTypeId(ty.id)} className="peer absolute inset-0 h-full w-full cursor-pointer opacity-0" />
              <span className="flex min-h-[54px] items-center justify-center rounded-lg border-[1.5px] border-line bg-canvas p-2 text-center text-[15px] font-bold
                peer-checked:border-brand peer-checked:bg-brand-soft peer-checked:text-brand peer-focus-visible:outline peer-focus-visible:outline-2 peer-focus-visible:outline-brand">
                {ty.label}
              </span>
            </label>
          ))}
        </div>
      </fieldset>

      <div className="grid grid-cols-1 gap-3 min-[400px]:grid-cols-2">
        <div>
          <label htmlFor="startDate" className="field-label">{text.from} <span className="text-bad">*</span></label>
          <input id="startDate" name="startDate" type="date" required value={start} min={addDays(today, -60)} max={addDays(today, 366)}
            onChange={(e) => { setStart(e.target.value); if (!end || end < e.target.value) setEnd(e.target.value); }}
            className="input input-lg" />
        </div>
        <div>
          <label htmlFor="endDate" className="field-label">{text.to} <span className="text-bad">*</span></label>
          <input id="endDate" name="endDate" type="date" required value={end} min={start || undefined} max={addDays(today, 366)}
            onChange={(e) => setEnd(e.target.value)} className="input input-lg" />
        </div>
      </div>

      {days > 0 && (
        <div className="tnum rounded-lg bg-brand-soft px-4 py-2.5 text-lg font-extrabold text-brand">
          {fill(text.daysCount, { n: days })}
          {type?.left != null && days > type.left && (
            <div className="text-sm font-semibold text-pending">{fill(text.overBalance, { type: type.label, n: Math.max(0, type.left) })}</div>
          )}
        </div>
      )}

      <div>
        <label htmlFor="reason" className="field-label">{text.reason}</label>
        <textarea id="reason" name="reason" rows={3} maxLength={1000} placeholder={text.reasonPh} className="input" />
      </div>
      <div className="grid grid-cols-1 gap-3 min-[400px]:grid-cols-2">
        <div>
          <label htmlFor="coverBy" className="field-label">{text.cover}</label>
          <input id="coverBy" name="coverBy" maxLength={120} className="input" />
        </div>
        <div>
          <label htmlFor="contact" className="field-label">{text.contact}</label>
          <input id="contact" name="contact" type="tel" inputMode="tel" maxLength={40} dir="ltr" className="input" />
        </div>
      </div>
      <div>
        <label htmlFor="attachment" className="field-label">{text.attachment}</label>
        <input id="attachment" name="attachment" type="file" accept="image/*,application/pdf"
          className="block w-full min-w-0 max-w-full text-sm file:me-3 file:rounded-lg file:border-0 file:bg-sunk file:px-4 file:py-2.5 file:font-bold file:text-ink" />
        <p className="mt-1.5 text-sm text-muted">
          {type?.requiresAttachment ? fill(text.attachmentReq, { type: type.label }) : text.attachmentOpt}
        </p>
      </div>

      {error && <p role="alert" className="alert-err">{error}</p>}
      <button className="btn-primary btn-lg" disabled={busy}>{busy ? text.sending : text.submit}</button>
      <Link href="/me" className="justify-self-center text-sm font-semibold text-muted hover:text-ink">{text.back}</Link>
    </form>
  );
}
