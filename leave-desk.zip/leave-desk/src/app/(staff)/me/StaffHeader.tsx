import Link from "next/link";
import { Logo } from "@/components/Logo";
import { LangSelect } from "@/components/LangSelect";
import { staffLogout } from "../actions";
import type { T } from "@/lib/i18n";

export function StaffHeader({ lang, t, company }: { lang: string; t: T; company: string }) {
  return (
    <header className="flex items-center justify-between gap-3">
      <Link href="/me" className="flex min-w-0 flex-1 items-center gap-2.5">
        <Logo size={38} />
        <div className="min-w-0">
          <div className="font-extrabold leading-tight">{t("appName")}</div>
          <div className="truncate text-sm text-muted">{company}</div>
        </div>
      </Link>
      <div className="flex shrink-0 items-center gap-1.5">
        <LangSelect lang={lang} label={t("language")} />
        <form action={staffLogout}>
          <button className="btn-ghost btn-sm whitespace-nowrap rounded-full px-2.5 py-2">{t("signOut")}</button>
        </form>
      </div>
    </header>
  );
}
