import { requireStaff } from "@/lib/auth";
import { getT } from "@/lib/lang";
import { companyName } from "@/lib/settings";
import { StaffHeader } from "../StaffHeader";
import { PinForm } from "./PinForm";

export const dynamic = "force-dynamic";
export const metadata = { title: "Change PIN" };

export default async function PinPage() {
  await requireStaff();
  const { lang, t } = await getT();
  const keys = ["currentPin", "newPin", "newPin2", "savePin", "pinSaved", "errPinWrong", "errPinFormat", "errPinMatch", "back"] as const;
  return (
    <>
      <StaffHeader lang={lang} t={t} company={await companyName()} />
      <h1 className="text-2xl font-extrabold">{t("changePin")}</h1>
      <PinForm text={Object.fromEntries(keys.map((k) => [k, t(k)]))} />
    </>
  );
}
