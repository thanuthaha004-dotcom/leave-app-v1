"use client";

import { noReset } from "@/components/noReset";
import Link from "next/link";
import { useActionState } from "react";
import { changePin } from "../../actions";

export function PinForm({ text }: { text: Record<string, string> }) {
  const [state, action, pending] = useActionState(changePin, undefined);
  if (state?.ok) {
    return (
      <div className="card grid gap-4 p-5">
        <p className="alert-ok">{text.pinSaved}</p>
        <Link href="/me" className="btn-primary btn-lg">{text.back}</Link>
      </div>
    );
  }
  const pinInput = (id: string, label: string, auto: string) => (
    <div>
      <label htmlFor={id} className="field-label">{label}</label>
      <input id={id} name={id} type="password" inputMode="numeric" maxLength={6} required autoComplete={auto} dir="ltr"
        className="input input-lg tracking-[0.4em]" />
    </div>
  );
  return (
    <form onSubmit={noReset(action)} className="card grid gap-4 p-5">
      {pinInput("current", text.currentPin, "current-password")}
      {pinInput("next", text.newPin, "new-password")}
      {pinInput("again", text.newPin2, "new-password")}
      {state?.error && <p role="alert" className="alert-err">{text[state.error]}</p>}
      <button className="btn-primary btn-lg" disabled={pending}>{text.savePin}</button>
      <Link href="/me" className="justify-self-center text-sm font-semibold text-muted">{text.back}</Link>
    </form>
  );
}
