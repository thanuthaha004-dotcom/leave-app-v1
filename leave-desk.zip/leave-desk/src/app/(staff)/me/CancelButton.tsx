"use client";

import { useState, useTransition } from "react";
import { cancelLeave } from "../actions";

export function CancelButton({ id, text }: { id: string; text: { cancel: string; sure: string; yes: string; keep: string } }) {
  const [asking, setAsking] = useState(false);
  const [pending, start] = useTransition();
  if (!asking) {
    return <button onClick={() => setAsking(true)} className="btn-ghost btn-sm justify-self-start">{text.cancel}</button>;
  }
  return (
    <div className="flex flex-wrap items-center gap-2 rounded-lg bg-bad-soft p-2.5">
      <span className="text-sm font-semibold text-bad">{text.sure}</span>
      <button disabled={pending} onClick={() => start(() => cancelLeave(id))} className="btn-bad btn-sm">{text.yes}</button>
      <button disabled={pending} onClick={() => setAsking(false)} className="btn-ghost btn-sm">{text.keep}</button>
    </div>
  );
}
