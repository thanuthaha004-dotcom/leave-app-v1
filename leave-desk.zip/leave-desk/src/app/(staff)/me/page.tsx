import Link from "next/link";
import { desc, eq } from "drizzle-orm";
import { db, leaveRequests } from "@/db";
import { requireStaff } from "@/lib/auth";
import { getT } from "@/lib/lang";
import { companyName } from "@/lib/settings";
import { balancesFor, typeLabel } from "@/lib/leave";
import { fmtDate, fmtDateTime, todayIso } from "@/lib/dates";
import { StatusPill } from "@/components/StatusPill";
import { StaffHeader } from "./StaffHeader";
import { CancelButton } from "./CancelButton";

export const dynamic = "force-dynamic";
export const metadata = { title: "My leave" };

export default async function MePage() {
  const emp = await requireStaff();
  const { lang, t } = await getT();
  const year = Number(todayIso().slice(0, 4));
  const [balances, requests] = await Promise.all([
    balancesFor(emp.id, year),
    db.query.leaveRequests.findMany({
      where: eq(leaveRequests.employeeId, emp.id),
      with: { leaveType: true },
      orderBy: desc(leaveRequests.createdAt),
      limit: 30,
    }),
  ]);
  const shown = balances.filter((b) => ["ANNUAL", "SICK"].includes(b.code) || b.used + b.pending > 0);

  return (
    <>
      <StaffHeader lang={lang} t={t} company={await companyName()} />

      <section className="grid gap-3">
        <h1 className="text-2xl font-extrabold">{t("hello", { name: emp.name.split(" ")[0] })}</h1>
        <Link href="/me/apply" className="btn-primary btn-lg">
          <svg aria-hidden viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M12 5v14M5 12h14" /></svg>
          {t("apply")}
        </Link>
      </section>

      {shown.length > 0 && (
        <section className="grid gap-2">
          <h2 className="label">{t("balance", { year })}</h2>
          <div className="grid grid-cols-2 gap-3">
            {shown.map((b) => (
              <div key={b.typeId} className="card grid gap-0.5 p-3.5">
                <div className="text-sm font-semibold text-muted">{typeLabel(b, lang)}</div>
                <div className="tnum text-2xl font-extrabold text-brand">{t("daysLeft", { n: Math.max(0, b.left) })}</div>
                <div className="tnum text-xs text-muted">
                  {t("usedOf", { used: b.used, total: b.allowed })}
                  {b.pending > 0 && <> · {t("pendingDays", { n: b.pending })}</>}
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      <section className="grid gap-2">
        <h2 className="label">{t("myRequests")}</h2>
        {requests.length === 0 ? (
          <div className="rounded-xl border border-dashed border-line p-6 text-center text-muted">{t("none")}</div>
        ) : (
          <ul className="grid gap-2.5">
            {requests.map((r) => (
              <li key={r.id} className="card grid gap-1.5 p-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <strong className="text-[16px]">{typeLabel(r.leaveType, lang)}</strong>
                  <StatusPill status={r.status} label={t(r.status)} />
                </div>
                <div className="tnum font-semibold">
                  {fmtDate(r.startDate, lang)} → {fmtDate(r.endDate, lang)} · {t("daysCount", { n: r.days })}
                </div>
                <div className="text-sm text-muted">
                  {t("requestNo")} <span dir="ltr" className="font-mono">{r.refNo}</span> · {t("sentOn", { date: fmtDateTime(r.createdAt, lang) })}
                </div>
                {r.hrNote && (
                  <div className="rounded-lg bg-sunk px-3 py-2 text-sm"><b>{t("hrNote")}:</b> {r.hrNote}</div>
                )}
                {r.status === "PENDING" && (
                  <CancelButton id={r.id} text={{ cancel: t("cancel"), sure: t("cancelSure"), yes: t("yesCancel"), keep: t("keep") }} />
                )}
              </li>
            ))}
          </ul>
        )}
      </section>

      <Link href="/me/pin" className="justify-self-center text-sm font-semibold text-brand underline-offset-4 hover:underline">{t("changePin")}</Link>
    </>
  );
}
