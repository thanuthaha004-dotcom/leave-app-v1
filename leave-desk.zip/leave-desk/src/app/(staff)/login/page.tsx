import { redirect } from "next/navigation";
import { getStaff } from "@/lib/auth";
import { getT } from "@/lib/lang";
import { companyName } from "@/lib/settings";
import { Logo } from "@/components/Logo";
import { LangSelect } from "@/components/LangSelect";
import { LoginForm } from "./LoginForm";

export const dynamic = "force-dynamic";
export const metadata = { title: "Sign in" };

export default async function LoginPage() {
  if (await getStaff()) redirect("/me");
  const { lang, t } = await getT();
  return (
    <>
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Logo />
          <div>
            <div className="text-lg font-extrabold leading-tight">{t("appName")}</div>
            <div className="text-sm text-muted">{await companyName()}</div>
          </div>
        </div>
        <LangSelect lang={lang} label={t("language")} />
      </div>
      <div className="card mt-6 grid gap-5 p-5 sm:p-6">
        <h1 className="text-xl font-extrabold [text-wrap:balance]">{t("loginTitle")}</h1>
        <LoginForm
          text={{ empId: t("empId"), pin: t("pin"), signIn: t("signIn"), signingIn: t("signingIn"), errLogin: t("errLogin"), errLocked: t("errLocked") }}
        />
        <p className="text-sm text-muted">{t("loginHelp")}</p>
      </div>
    </>
  );
}
