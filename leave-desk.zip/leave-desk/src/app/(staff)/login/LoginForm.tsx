"use client";

import { noReset } from "@/components/noReset";
import { useActionState } from "react";
import { staffLogin } from "../actions";

type Text = Record<"empId" | "pin" | "signIn" | "signingIn" | "errLogin" | "errLocked", string>;

export function LoginForm({ text }: { text: Text }) {
  const [state, action, pending] = useActionState(staffLogin, undefined);
  return (
    <form onSubmit={noReset(action)} className="grid gap-4">
      <div>
        <label htmlFor="empNo" className="field-label">{text.empId}</label>
        <input id="empNo" name="empNo" required autoComplete="username" autoCapitalize="characters" dir="ltr"
          className="input input-lg uppercase" placeholder="EMP-0001" />
      </div>
      <div>
        <label htmlFor="pin" className="field-label">{text.pin}</label>
        <input id="pin" name="pin" required type="password" inputMode="numeric" autoComplete="current-password"
          dir="ltr" maxLength={6} className="input input-lg tracking-[0.4em]" />
      </div>
      {state?.error && <p role="alert" className="alert-err">{text[state.error as "errLogin" | "errLocked"] ?? text.errLogin}</p>}
      <button className="btn-primary btn-lg" disabled={pending}>{pending ? text.signingIn : text.signIn}</button>
    </form>
  );
}
