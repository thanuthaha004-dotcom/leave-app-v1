import { getLang } from "@/lib/lang";
import { dirOf } from "@/lib/i18n";

export default async function StaffLayout({ children }: { children: React.ReactNode }) {
  const lang = await getLang();
  return (
    <div lang={lang} dir={dirOf(lang)} className="overflow-x-clip text-base">
      <div className="mx-auto grid max-w-xl grid-cols-[minmax(0,1fr)] gap-4 px-4 pb-16 pt-5">{children}</div>
    </div>
  );
}
