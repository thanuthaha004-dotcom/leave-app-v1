"use client";

import { useRouter } from "next/navigation";
import { useTransition } from "react";
import { setLanguage } from "@/app/(staff)/actions";
import { LANGS } from "@/lib/i18n";

export function LangSelect({ lang, label }: { lang: string; label: string }) {
  const router = useRouter();
  const [pending, start] = useTransition();
  return (
    <label className="relative inline-flex items-center">
      <span className="sr-only">{label}</span>
      <svg aria-hidden viewBox="0 0 24 24" className="pointer-events-none absolute start-2.5 h-4 w-4 text-muted" fill="none" stroke="currentColor" strokeWidth="2">
        <circle cx="12" cy="12" r="9" /><path d="M3 12h18M12 3c2.5 2.7 3.8 5.7 3.8 9s-1.3 6.3-3.8 9c-2.5-2.7-3.8-5.7-3.8-9S9.5 5.7 12 3z" />
      </svg>
      <select
        id="lang"
        value={lang}
        disabled={pending}
        onChange={(e) => start(async () => { await setLanguage(e.target.value); router.refresh(); })}
        className="max-w-[7.5rem] appearance-none truncate rounded-full border border-line bg-white py-2 pe-3 ps-8 text-sm font-semibold"
      >
        {LANGS.map((l) => <option key={l.code} value={l.code}>{l.label}</option>)}
      </select>
    </label>
  );
}
