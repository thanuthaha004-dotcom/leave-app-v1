export function Logo({ size = 40 }: { size?: number }) {
  return (
    <div
      aria-hidden
      style={{ width: size, height: size, fontSize: size * 0.45 }}
      className="grid shrink-0 place-items-center rounded-[22%] bg-brand font-extrabold text-white"
    >
      L
    </div>
  );
}
