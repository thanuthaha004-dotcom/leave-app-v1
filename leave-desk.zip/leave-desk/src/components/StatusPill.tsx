const STYLE: Record<string, string> = {
  PENDING: "bg-pending-soft text-pending",
  APPROVED: "bg-ok-soft text-ok",
  REJECTED: "bg-bad-soft text-bad",
  CANCELLED: "bg-sunk text-muted",
};

export function StatusPill({ status, label }: { status: string; label?: string }) {
  return (
    <span className={`inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-bold ${STYLE[status] ?? STYLE.CANCELLED}`}>
      <span className="h-1.5 w-1.5 rounded-full bg-current" aria-hidden />
      {label ?? status.charAt(0) + status.slice(1).toLowerCase()}
    </span>
  );
}
