import { startTransition, type FormEvent } from "react";

/**
 * React clears a form after its action runs. For sign-in and edit forms that would wipe what the
 * person typed when there is an error, so these forms submit through this handler instead.
 */
export function noReset(action: (fd: FormData) => void) {
  return (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    startTransition(() => action(fd));
  };
}
