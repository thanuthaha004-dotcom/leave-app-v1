import "server-only";
import { cache } from "react";
import { redirect } from "next/navigation";
import { eq } from "drizzle-orm";
import { db, employees, users } from "@/db";
import { readSession } from "./session";

export const LOCK_AFTER = 5; // wrong tries
export const LOCK_MINUTES = 15;

export const getStaff = cache(async () => {
  const s = await readSession("staff");
  if (!s) return null;
  const e = await db.query.employees.findFirst({ where: eq(employees.id, s.sub) });
  if (!e || !e.active || e.tokenVersion !== s.v) return null;
  return e;
});

export async function requireStaff() {
  const e = await getStaff();
  if (!e) redirect("/login");
  return e;
}

export const getHR = cache(async () => {
  const s = await readSession("hr");
  if (!s) return null;
  const u = await db.query.users.findFirst({ where: eq(users.id, s.sub) });
  if (!u || !u.active || u.tokenVersion !== s.v) return null;
  return u;
});

export async function requireHR() {
  const u = await getHR();
  if (!u) redirect("/hr/login");
  return u;
}

export async function requireAdmin() {
  const u = await requireHR();
  if (u.role !== "ADMIN") redirect("/hr");
  return u;
}
