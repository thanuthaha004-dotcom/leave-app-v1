import "server-only";
import { db, auditLog } from "@/db";

export async function audit(
  actorType: "HR" | "STAFF" | "SYSTEM",
  actorId: string | null,
  action: string,
  entity: string,
  entityId: string | null,
  details?: Record<string, unknown>,
) {
  try {
    await db.insert(auditLog).values({ actorType, actorId, action, entity, entityId, details: details ?? null });
  } catch (e) {
    console.error("Audit log write failed", e);
  }
}
