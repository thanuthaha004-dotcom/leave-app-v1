import "server-only";
import bcrypt from "bcryptjs";
import { randomInt } from "crypto";

const WEAK = new Set(["0000", "1111", "1234", "4321", "2222", "9999", "1212", "0123"]);

export function generatePin(): string {
  for (;;) {
    const p = String(randomInt(0, 10000)).padStart(4, "0");
    if (!WEAK.has(p)) return p;
  }
}
export const hashPin = (pin: string) => bcrypt.hash(pin, 10);
export const hashPassword = (pw: string) => bcrypt.hash(pw, 12);
export const verifyHash = (plain: string, hash: string) => bcrypt.compare(plain, hash);
export const isValidPin = (p: string) => /^\d{4,6}$/.test(p);

let dummy: string | null = null;
export async function dummyVerify(plain: string) {
  dummy ??= await bcrypt.hash("not-a-real-pin", 10);
  await bcrypt.compare(plain, dummy);
}
