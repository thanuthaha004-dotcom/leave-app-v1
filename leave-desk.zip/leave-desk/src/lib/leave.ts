import "server-only";
import { and, eq, gte, inArray, lte, sql } from "drizzle-orm";
import { db, holidays, leaveRequests, leaveTypes, type Employee, type LeaveType } from "@/db";
import { countLeaveDays } from "./days";
export { countLeaveDays };
import { getSettings } from "./settings";

export function parseWeekend(v: string | undefined): number[] {
  return (v ?? "").split(",").map((x) => parseInt(x, 10)).filter((x) => x >= 0 && x <= 6);
}

export async function daysForRequest(emp: Pick<Employee, "staffType">, type: Pick<LeaveType, "countMode">, start: string, end: string) {
  if (type.countMode === "CALENDAR") return countLeaveDays(start, end, "CALENDAR", [], new Set());
  const s = await getSettings();
  const weekend = parseWeekend(s[`weekend_${emp.staffType}`]);
  const hs = await db.select({ date: holidays.date }).from(holidays).where(and(gte(holidays.date, start), lte(holidays.date, end)));
  return countLeaveDays(start, end, "WORKING", weekend, new Set(hs.map((h) => h.date)));
}

export type Balance = { typeId: string; code: string; name: string; names: Record<string, string> | null; allowed: number; used: number; pending: number; left: number };

/** Yearly balances for leave types that have a limit. Approved leave counts by its first day's year. */
export async function balancesFor(employeeId: string, year: number): Promise<Balance[]> {
  const types = await db.select().from(leaveTypes).where(eq(leaveTypes.active, true)).orderBy(leaveTypes.sortOrder);
  const limited = types.filter((t) => t.daysPerYear != null);
  if (!limited.length) return [];
  const rows = await db
    .select({ typeId: leaveRequests.leaveTypeId, status: leaveRequests.status, total: sql<number>`sum(${leaveRequests.days})::int` })
    .from(leaveRequests)
    .where(and(
      eq(leaveRequests.employeeId, employeeId),
      inArray(leaveRequests.status, ["APPROVED", "PENDING"]),
      gte(leaveRequests.startDate, `${year}-01-01`),
      lte(leaveRequests.startDate, `${year}-12-31`),
    ))
    .groupBy(leaveRequests.leaveTypeId, leaveRequests.status);
  return limited.map((t) => {
    const used = rows.find((r) => r.typeId === t.id && r.status === "APPROVED")?.total ?? 0;
    const pending = rows.find((r) => r.typeId === t.id && r.status === "PENDING")?.total ?? 0;
    return { typeId: t.id, code: t.code, name: t.name, names: t.names ?? null, allowed: t.daysPerYear!, used, pending, left: t.daysPerYear! - used };
  });
}

/** e.g. LV-261018-4821 */
export function newRefNo(today: string): string {
  return `LV-${today.slice(2, 4)}${today.slice(5, 7)}${today.slice(8, 10)}-${Math.floor(1000 + Math.random() * 9000)}`;
}

export function typeLabel(t: { name: string; names?: Record<string, string> | null }, lang: string) {
  return (lang !== "en" && t.names?.[lang]) || t.name;
}
