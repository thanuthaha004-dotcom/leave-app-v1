import "server-only";
import { SignJWT, jwtVerify } from "jose";
import { cookies, headers } from "next/headers";

export const STAFF_COOKIE = "ld_staff";
export const HR_COOKIE = "ld_hr";
type Kind = "staff" | "hr";
const COOKIE: Record<Kind, string> = { staff: STAFF_COOKIE, hr: HR_COOKIE };
// Staff stay signed in on their phone for 30 days; HR sessions last 12 hours.
const MAX_AGE: Record<Kind, number> = { staff: 60 * 60 * 24 * 30, hr: 60 * 60 * 12 };

function secret() {
  const s = process.env.SESSION_SECRET;
  if (!s || s.length < 32) throw new Error("SESSION_SECRET must be set to at least 32 characters.");
  return new TextEncoder().encode(s);
}

/** True when the browser reached us over HTTPS (Caddy sets X-Forwarded-Proto). */
async function isHttps() {
  const h = await headers();
  return (h.get("x-forwarded-proto") ?? "").split(",")[0].trim() === "https";
}

export async function startSession(kind: Kind, sub: string, version: number) {
  const token = await new SignJWT({ v: version, k: kind })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(sub)
    .setIssuedAt()
    .setExpirationTime(`${MAX_AGE[kind]}s`)
    .sign(secret());
  (await cookies()).set(COOKIE[kind], token, {
    httpOnly: true,
    sameSite: "lax",
    secure: await isHttps(),
    path: "/",
    maxAge: MAX_AGE[kind],
  });
}

export async function endSession(kind: Kind) {
  (await cookies()).delete(COOKIE[kind]);
}

export async function readSession(kind: Kind): Promise<{ sub: string; v: number } | null> {
  const token = (await cookies()).get(COOKIE[kind])?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secret(), { algorithms: ["HS256"] });
    if (payload.k !== kind || typeof payload.sub !== "string") return null;
    return { sub: payload.sub, v: Number(payload.v ?? 0) };
  } catch {
    return null;
  }
}
