// Dates are handled as plain 'YYYY-MM-DD' strings so time zones never shift a leave day.

export const APP_TZ = process.env.APP_TIMEZONE || "Asia/Dubai";
const ISO = /^\d{4}-\d{2}-\d{2}$/;

export function isIsoDate(s: unknown): s is string {
  if (typeof s !== "string" || !ISO.test(s)) return false;
  const d = new Date(s + "T00:00:00Z");
  return !isNaN(d.getTime()) && d.toISOString().slice(0, 10) === s;
}

/** Today's date in the company time zone. */
export function todayIso(tz = APP_TZ): string {
  return new Intl.DateTimeFormat("en-CA", { timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
}

export function addDays(iso: string, n: number): string {
  const d = new Date(iso + "T00:00:00Z");
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}

export function diffDays(a: string, b: string): number {
  return Math.round((Date.parse(b + "T00:00:00Z") - Date.parse(a + "T00:00:00Z")) / 864e5);
}

export function weekday(iso: string): number {
  return new Date(iso + "T00:00:00Z").getUTCDay(); // 0 = Sunday
}

const LOCALES: Record<string, string> = {
  en: "en-GB", ar: "ar-AE-u-nu-latn", hi: "hi-IN-u-nu-latn", ur: "ur-PK-u-nu-latn", ml: "ml-IN-u-nu-latn",
};

/** e.g. 18 Oct 2026 */
export function fmtDate(iso: string | null | undefined, lang = "en"): string {
  if (!iso) return "";
  return new Intl.DateTimeFormat(LOCALES[lang] ?? "en-GB", { day: "numeric", month: "short", year: "numeric", timeZone: "UTC" })
    .format(new Date(iso.slice(0, 10) + "T00:00:00Z"));
}

/** e.g. 18 Oct 2026, 14:05 in the company time zone */
export function fmtDateTime(d: Date | string | null | undefined, lang = "en"): string {
  if (!d) return "";
  return new Intl.DateTimeFormat(LOCALES[lang] ?? "en-GB", {
    day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit", timeZone: APP_TZ,
  }).format(new Date(d));
}
