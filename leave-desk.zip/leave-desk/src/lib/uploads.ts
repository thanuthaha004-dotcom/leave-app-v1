import "server-only";
import { mkdir, readFile, writeFile } from "fs/promises";
import path from "path";
import { randomUUID } from "crypto";

export const UPLOAD_DIR = path.resolve(process.env.UPLOAD_DIR || "./uploads");
export const MAX_UPLOAD = 8 * 1024 * 1024;
const ALLOWED: Record<string, string> = {
  "image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp", "image/heic": ".heic", "application/pdf": ".pdf",
};

export function isAllowedUpload(f: File) {
  return f.size > 0 && f.size <= MAX_UPLOAD && f.type in ALLOWED;
}

export async function saveUpload(f: File): Promise<string> {
  await mkdir(UPLOAD_DIR, { recursive: true });
  const name = randomUUID() + ALLOWED[f.type];
  await writeFile(path.join(UPLOAD_DIR, name), Buffer.from(await f.arrayBuffer()));
  return name;
}

export async function readUpload(storedName: string) {
  if (!/^[0-9a-f-]{36}\.[a-z]+$/.test(storedName)) throw new Error("bad name");
  return readFile(path.join(UPLOAD_DIR, storedName));
}
