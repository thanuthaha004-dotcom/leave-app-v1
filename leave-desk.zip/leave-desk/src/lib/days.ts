// Pure day counting, shared by the server and the apply form preview.
import { addDays, diffDays, weekday } from "./dates";

export function countLeaveDays(
  start: string, end: string, mode: "CALENDAR" | "WORKING", weekend: number[], holidaySet: Set<string>,
): number {
  if (!start || !end || end < start) return 0;
  if (mode === "CALENDAR") return diffDays(start, end) + 1;
  let n = 0;
  for (let d = start; d <= end; d = addDays(d, 1)) {
    if (!weekend.includes(weekday(d)) && !holidaySet.has(d)) n++;
  }
  return n;
}
