import "server-only";
import webpush from "web-push";
import nodemailer from "nodemailer";
import { and, eq, inArray } from "drizzle-orm";
import { db, leaveRequests, pushSubscriptions, users } from "@/db";
import { fmtDate } from "./dates";

export const pushEnabled = () => Boolean(process.env.VAPID_PUBLIC_KEY && process.env.VAPID_PRIVATE_KEY);
export const emailEnabled = () => Boolean(process.env.SMTP_HOST);

let vapidReady = false;
function initPush() {
  if (vapidReady || !pushEnabled()) return pushEnabled();
  webpush.setVapidDetails(
    process.env.VAPID_SUBJECT || "mailto:hr@example.com",
    process.env.VAPID_PUBLIC_KEY!,
    process.env.VAPID_PRIVATE_KEY!,
  );
  vapidReady = true;
  return true;
}

const esc = (s: string) => s.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]!);

/** Tells every active HR user about a new leave request: push to their devices and, if set up, email. */
export async function notifyNewRequest(requestId: string) {
  const r = await db.query.leaveRequests.findFirst({
    where: eq(leaveRequests.id, requestId),
    with: { employee: true, leaveType: true },
  });
  if (!r) return;
  const title = `New leave request: ${r.employee.name}`;
  const body = `${r.leaveType.name} · ${fmtDate(r.startDate)} to ${fmtDate(r.endDate)} · ${r.days} day${r.days === 1 ? "" : "s"}`;
  const hr = await db.select().from(users).where(eq(users.active, true));

  if (initPush() && hr.length) {
    const subs = await db.select().from(pushSubscriptions).where(inArray(pushSubscriptions.userId, hr.map((u) => u.id)));
    await Promise.all(subs.map(async (s) => {
      try {
        await webpush.sendNotification(
          { endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } },
          JSON.stringify({ title, body, url: "/hr", tag: r.id }),
          { TTL: 60 * 60 * 24 },
        );
      } catch (e: unknown) {
        const code = (e as { statusCode?: number }).statusCode;
        if (code === 404 || code === 410) await db.delete(pushSubscriptions).where(eq(pushSubscriptions.id, s.id));
        else console.error("Push failed", code ?? e);
      }
    }));
  }

  const to = hr.filter((u) => u.emailAlerts).map((u) => u.email);
  if (emailEnabled() && to.length) {
    const base = (process.env.APP_URL || "").replace(/\/$/, "");
    try {
      await mailer().sendMail({
        from: process.env.SMTP_FROM || process.env.SMTP_USER,
        to,
        subject: `${title} (${r.employee.empNo})`,
        text: `${title}\n${body}\nRequest ${r.refNo}\n${r.reason ? "Reason: " + r.reason + "\n" : ""}${base ? "\nOpen the HR dashboard: " + base + "/hr" : ""}`,
        html:
          `<p><b>${esc(r.employee.name)}</b> (${esc(r.employee.empNo)}${r.employee.site ? ", " + esc(r.employee.site) : ""}) applied for <b>${esc(r.leaveType.name)}</b>.</p>` +
          `<p>${esc(fmtDate(r.startDate))} to ${esc(fmtDate(r.endDate))} · ${r.days} day${r.days === 1 ? "" : "s"}</p>` +
          (r.reason ? `<p>Reason: ${esc(r.reason)}</p>` : "") +
          `<p>Request ${esc(r.refNo)}${base ? ` · <a href="${esc(base)}/hr">Open the HR dashboard</a>` : ""}</p>`,
      });
    } catch (e) {
      console.error("Email alert failed", e);
    }
  }
}

let transport: ReturnType<typeof nodemailer.createTransport> | null = null;
function mailer() {
  transport ??= nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: Number(process.env.SMTP_PORT) === 465,
    auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASSWORD } : undefined,
  });
  return transport;
}

export async function savePushSubscription(userId: string, sub: { endpoint: string; keys: { p256dh: string; auth: string } }) {
  await db.insert(pushSubscriptions)
    .values({ userId, endpoint: sub.endpoint, p256dh: sub.keys.p256dh, auth: sub.keys.auth })
    .onConflictDoUpdate({ target: pushSubscriptions.endpoint, set: { userId, p256dh: sub.keys.p256dh, auth: sub.keys.auth } });
}

export async function removePushSubscription(userId: string, endpoint: string) {
  await db.delete(pushSubscriptions).where(and(eq(pushSubscriptions.userId, userId), eq(pushSubscriptions.endpoint, endpoint)));
}
