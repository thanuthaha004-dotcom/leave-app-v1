#!/bin/sh
# Runs every time the app container starts.
set -e
node scripts/migrate.mjs   # update the database structure if needed
node scripts/seed.mjs      # first run only: administrator, leave types, settings
exec node_modules/.bin/next start
