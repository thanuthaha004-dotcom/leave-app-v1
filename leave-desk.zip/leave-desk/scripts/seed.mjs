// First-run setup: creates the first administrator, default leave types and settings.
// It only adds what is missing, so it is safe to run on every start.
import pg from "pg";
import bcrypt from "bcryptjs";

const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });
const q = (text, params) => pool.query(text, params);

// 1. First administrator
const { rows: [{ count: userCount }] } = await q("select count(*)::int as count from users");
if (userCount === 0) {
  const email = (process.env.ADMIN_EMAIL || "").trim().toLowerCase();
  const password = process.env.ADMIN_PASSWORD || "";
  if (!email || password.length < 10) {
    console.error("No HR users exist yet. Set ADMIN_EMAIL and ADMIN_PASSWORD (10+ characters) in .env, then restart.");
  } else {
    await q(
      "insert into users (id, email, name, password_hash, role) values (gen_random_uuid()::text, $1, $2, $3, 'ADMIN')",
      [email, process.env.ADMIN_NAME || "Administrator", await bcrypt.hash(password, 12)],
    );
    console.log(`Created administrator ${email}. You can remove ADMIN_PASSWORD from .env now.`);
  }
}

// 2. Default leave types. Check these against your company policy and UAE labour law in Settings.
const types = [
  ["ANNUAL", "Annual leave", 30, "CALENDAR", false, { ar: "إجازة سنوية", hi: "सालाना छुट्टी", ur: "سالانہ چھٹی", ml: "വാർഷിക അവധി" }],
  ["SICK", "Sick leave", 90, "CALENDAR", true, { ar: "إجازة مرضية", hi: "बीमारी की छुट्टी", ur: "بیماری کی چھٹی", ml: "രോഗ അവധി" }],
  ["EMERGENCY", "Emergency leave", null, "CALENDAR", false, { ar: "إجازة طارئة", hi: "आपातकालीन छुट्टी", ur: "ہنگامی چھٹی", ml: "അടിയന്തര അവധി" }],
  ["COMPASSIONATE", "Compassionate leave", 5, "CALENDAR", false, { ar: "إجازة حداد", hi: "शोक अवकाश", ur: "سوگ کی چھٹی", ml: "അനുശോചന അവധി" }],
  ["MATERNITY", "Maternity leave", 60, "CALENDAR", true, { ar: "إجازة أمومة", hi: "मातृत्व अवकाश", ur: "زچگی کی چھٹی", ml: "പ്രസവാവധി" }],
  ["PATERNITY", "Paternity leave", 5, "WORKING", false, { ar: "إجازة أبوة", hi: "पितृत्व अवकाश", ur: "پدری چھٹی", ml: "പിതൃത്വ അവധി" }],
  ["HAJJ", "Hajj leave", 30, "CALENDAR", false, { ar: "إجازة الحج", hi: "हज अवकाश", ur: "حج کی چھٹی", ml: "ഹജ്ജ് അവധി" }],
  ["STUDY", "Study leave", 10, "WORKING", false, { ar: "إجازة دراسية", hi: "अध्ययन अवकाश", ur: "تعلیمی چھٹی", ml: "പഠന അവധി" }],
  ["UNPAID", "Unpaid leave", null, "CALENDAR", false, { ar: "إجازة بدون راتب", hi: "बिना वेतन छुट्टी", ur: "بغیر تنخواہ چھٹی", ml: "ശമ്പളമില്ലാത്ത അവധി" }],
];
const { rows: [{ count: typeCount }] } = await q("select count(*)::int as count from leave_types");
if (typeCount === 0) {
  let order = 0;
  for (const [code, name, days, mode, attach, names] of types) {
    await q(
      "insert into leave_types (id, code, name, names, days_per_year, count_mode, requires_attachment, sort_order) values (gen_random_uuid()::text, $1, $2, $3, $4, $5, $6, $7)",
      [code, name, JSON.stringify(names), days, mode, attach, order++],
    );
  }
  console.log("Added default leave types.");
}

// 3. Settings
const defaults = {
  company_name: process.env.COMPANY_NAME || "Leave Desk",
  weekend_OFFICE: "6,0", // Saturday, Sunday (0 = Sunday … 6 = Saturday)
  weekend_SITE: "0", // Sunday
};
for (const [key, value] of Object.entries(defaults)) {
  await q("insert into settings (key, value) values ($1, $2) on conflict (key) do nothing", [key, value]);
}

await pool.end();
