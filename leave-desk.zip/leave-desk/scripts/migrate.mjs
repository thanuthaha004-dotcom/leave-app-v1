// Applies any new SQL migrations from /drizzle. Safe to run on every start.
import pg from "pg";
import { drizzle } from "drizzle-orm/node-postgres";
import { migrate } from "drizzle-orm/node-postgres/migrator";

const url = process.env.DATABASE_URL;
if (!url) { console.error("DATABASE_URL is not set."); process.exit(1); }

const pool = new pg.Pool({ connectionString: url });
// The database container can take a few seconds to accept connections.
for (let i = 1; ; i++) {
  try { await pool.query("select 1"); break; }
  catch (e) {
    if (i >= 30) { console.error("Could not reach the database:", e.message); process.exit(1); }
    await new Promise((r) => setTimeout(r, 2000));
  }
}
await migrate(drizzle(pool), { migrationsFolder: new URL("../drizzle", import.meta.url).pathname });
console.log("Database is up to date.");
await pool.end();
