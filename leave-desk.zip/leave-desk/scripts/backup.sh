#!/usr/bin/env bash
# Backs up the database and uploaded documents into ./backups and keeps 30 days.
# Run by hand or every night from cron (see README.md, step 9).
set -euo pipefail
cd "$(dirname "$0")/.."
DIR=${BACKUP_DIR:-./backups}
mkdir -p "$DIR"
TS=$(date +%Y%m%d-%H%M)
docker compose exec -T db pg_dump -U leavedesk -d leavedesk -Fc > "$DIR/db-$TS.dump"
docker compose exec -T app tar czf - -C /app uploads > "$DIR/uploads-$TS.tgz"
find "$DIR" -name 'db-*.dump' -mtime +30 -delete
find "$DIR" -name 'uploads-*.tgz' -mtime +30 -delete
echo "Backup saved: $DIR/db-$TS.dump and $DIR/uploads-$TS.tgz"
