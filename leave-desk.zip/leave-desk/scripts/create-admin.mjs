// Emergency access: creates (or resets) an administrator and prints a temporary password.
// On the server:  docker compose exec app node scripts/create-admin.mjs you@company.ae "Your Name"
import pg from "pg";
import bcrypt from "bcryptjs";
import { randomBytes } from "crypto";

const [email, name = "Administrator"] = process.argv.slice(2);
if (!email || !email.includes("@")) { console.error('Usage: node scripts/create-admin.mjs you@company.ae "Your Name"'); process.exit(1); }
const password = "Ld-" + randomBytes(6).toString("hex");
const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });
await pool.query(
  `insert into users (id, email, name, password_hash, role) values (gen_random_uuid()::text, $1, $2, $3, 'ADMIN')
   on conflict (email) do update set password_hash = excluded.password_hash, role = 'ADMIN', active = true,
     failed_logins = 0, locked_until = null, token_version = users.token_version + 1`,
  [email.trim().toLowerCase(), name, await bcrypt.hash(password, 12)],
);
await pool.end();
console.log(`Administrator ${email} can now sign in with the temporary password: ${password}`);
console.log("Change it straight away under My account.");
