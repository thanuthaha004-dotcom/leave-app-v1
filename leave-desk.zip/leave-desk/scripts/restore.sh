#!/usr/bin/env bash
# Restores a backup made by backup.sh. This REPLACES the current data.
# Usage: scripts/restore.sh backups/db-20261018-0200.dump [backups/uploads-20261018-0200.tgz]
set -euo pipefail
cd "$(dirname "$0")/.."
DB_FILE=${1:?Give the db-....dump file to restore}
UP_FILE=${2:-}
read -rp "This replaces all current Leave Desk data with $DB_FILE. Type YES to continue: " ok
[ "$ok" = "YES" ] || { echo "Stopped. Nothing changed."; exit 1; }
docker compose stop app
docker compose exec -T db pg_restore -U leavedesk -d leavedesk --clean --if-exists < "$DB_FILE"
if [ -n "$UP_FILE" ]; then
  docker compose run --rm --no-deps -T --entrypoint sh app -c "rm -rf /app/uploads/* && tar xzf - -C /app" < "$UP_FILE"
fi
docker compose start app
echo "Restore finished."
