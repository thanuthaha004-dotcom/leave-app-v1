# Leave Desk: notes for Claude Code

Leave application app for a UAE company with office staff and site labour. Self-hosted with Docker.
It's meant to grow into a small HR system (attendance, document expiry alerts, certificates, payroll export).

## Stack
- Next.js 15 (App Router, server components, server actions), React 19, TypeScript, Tailwind CSS 3
- PostgreSQL 16 through Drizzle ORM (`src/db/schema.ts`), with SQL migrations in `drizzle/`
- Sessions: signed JWT cookies (`jose`). `ld_staff` for employees (Employee ID + PIN), `ld_hr` for HR users (email + password)
- Notifications: `web-push` (VAPID) and `nodemailer` (SMTP), both optional by env
- Deploy: `docker-compose.yml` runs db, app and caddy (automatic HTTPS)

## Layout
- `src/app/(staff)/`: staff pages (`/login`, `/me`, `/me/apply`, `/me/pin`) and `actions.ts`. Translated.
- `src/app/hr/`: HR pages (`/hr/login`, and inside `(app)/`: dashboard, employees, export, settings, account) and `actions.ts`. English only.
- `src/app/api/`: `hr/requests` (dashboard polling), `hr/export` (CSV), `hr/push`, `attachments/[id]`, `health`
- `src/lib/`: `auth.ts` (requireStaff / requireHR / requireAdmin), `session.ts`, `leave.ts` (balances, day counts), `days.ts` (pure day counter), `dates.ts`, `i18n.ts`, `notify.ts`, `audit.ts`, `csv.ts`, `uploads.ts`, `pin.ts`, `settings.ts`
- `scripts/`: `migrate.mjs` and `seed.mjs` (both run on every container start and are idempotent), `create-admin.mjs`, `backup.sh`, `restore.sh`

## Rules
- **Every server action and API route checks the session first** with `requireStaff()`, `requireHR()` or `requireAdmin()` (or `getHR()`/`getStaff()` in API routes, returning 401). The middleware is only a convenience redirect.
- Staff may only read or change their own rows. Always filter by `employeeId = emp.id`.
- Record every change in `audit()`, with actor, action, entity and id.
- Leave dates are `'YYYY-MM-DD'` strings (Postgres `date`). Never convert them through local `Date` objects. Use the helpers in `lib/dates.ts`. The company time zone is `APP_TIMEZONE`, default Asia/Dubai.
- **Staff-facing text goes in `lib/i18n.ts` in all five languages** (en, ar, hi, ur, ml). Arabic and Urdu are right to left. Use logical CSS such as `ms-`, `me-`, `ps-`, `pe-` and `start-`, not left/right.
- Don't send secrets or hashes to the browser. Pass explicit field lists to client components, never whole DB rows.
- Forms that show errors use `noReset(action)` (`src/components/noReset.ts`) so typed values aren't cleared.
- Staff UI must work at 360px phone width with large tap targets. Many users are on low-end Android phones with mobile data.
- New modules link to `employees.id`. Add new tables in `src/db/schema.ts`, then run `npm run db:generate`. Never edit a migration that has already been applied; add a new one.

## Commands
- `npm run dev`: local dev (needs `DATABASE_URL`, `SESSION_SECRET`)
- `npm run typecheck` and `npm run build`: run both before handing over changes
- `npm run db:generate`: make a migration after a schema change. `npm run db:migrate` and `npm run db:seed` apply and seed.

## Ideas already planned
1. Supervisor approval step before HR (add `supervisorId` on employees, a `SUPERVISOR_APPROVED` status)
2. Team leave calendar view
3. Visa, Emirates ID and passport expiry tracking with alerts
4. Salary certificate and NOC requests
5. WhatsApp or SMS notifications to staff when a decision is made
